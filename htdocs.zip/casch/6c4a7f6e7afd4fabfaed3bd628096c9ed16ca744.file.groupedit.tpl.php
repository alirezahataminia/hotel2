<?php /* Smarty version Smarty-3.0.5, created on 2016-05-13 20:19:36
         compiled from "view/admin/admin\groupedit.tpl" */ ?>
<?php /*%%SmartyHeaderCode:322745735f790304328-79832578%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6c4a7f6e7afd4fabfaed3bd628096c9ed16ca744' => 
    array (
      0 => 'view/admin/admin\\groupedit.tpl',
      1 => 1463154571,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '322745735f790304328-79832578',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (!is_callable('smarty_function_ctrl')) include 'protected/libs/smarty_plugins\function.ctrl.php';
?><?php echo smarty_function_ctrl(array('filename'=>"groupedit",'side'=>"admin",'assign'=>"obj"),$_smarty_tpl);?>

<ul class="nav nav-tabs" role="tablist">
    <li role="presentation" class="active"><a href="#home" aria-controls="home" role="tab" data-toggle="tab">Group Edit</a></li>
    <li role="presentation"><a href="#profile" aria-controls="profile" role="tab" data-toggle="tab">
            sub Group
        </a></li>
</ul>
<div class="tab-content">
    <div role="tabpanel" class="tab-pane active" id="home">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    Group <small>Edit Group</small>
                </h1>
                <ol class="breadcrumb">
                    <li class="active">
                        <i class="fa fa-dashboard"></i> Dashboard
                    </li>
                </ol>
            </div>
        </div>
        <?php echo $_smarty_tpl->getVariable('obj')->value->message;?>

        <!-- /.row -->
        <div class="row">
            <div class="col-lg-12">
                <div class="col-lg-6">
                    <div class="btn-group" role="group" aria-label="...">
                        <button type="submit" class="btn btn-success" name="btnSubmit" form="sectionCmstypeForm">Save</button>
                        <button type="reset" class="btn btn-warning" form="sectionCmstypeForm">Reset</button>
                        <a type="button" class="btn btn-danger" href="?r=dashboard">Exit</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <form action="" method="post" id="sectionCmstypeForm" class="frm" enctype="multipart/form-data">
                    <input type="hidden" value="<?php echo $_smarty_tpl->getVariable('obj')->value->id;?>
" name="txtId">
                    <input type="hidden" value="<?php echo $_smarty_tpl->getVariable('obj')->value->section['parent'];?>
" name="txtParent">
                    <input type="hidden" value="<?php echo $_smarty_tpl->getVariable('obj')->value->section['order'];?>
" name="txtOrder">
                    <div class="form-group">
                        <label class="lblTitle">Title:</label>
                        <input class="form-control txtTitle" type="text" name="txtTitle" id="txtTitle" value="<?php echo $_smarty_tpl->getVariable('obj')->value->section['title'];?>
">
                        <p class="help-block color-red titleAlarm">
                            Title is required!
                        </p>
                    </div>
                    <div class="form-group">
                        <label>Module :</label>
                        <input class="form-control" type="text" name="txtModule" value="<?php echo $_smarty_tpl->getVariable('obj')->value->section['module'];?>
">
                    </div>
                    <div class="form-group">
                        <label>Language :</label>
                        <select class="form-control" name="txtLang">
                            <?php unset($_smarty_tpl->tpl_vars['smarty']->value['section']['i']);
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['name'] = 'i';
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'] = is_array($_loop=$_smarty_tpl->getVariable('obj')->value->lang) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show'] = true;
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['max'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'] = 1;
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'] > 0 ? 0 : $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop']-1;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show']) {
    $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'];
    if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'] == 0)
        $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show'] = false;
} else
    $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'] = 0;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show']):

            for ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'], $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] = 1;
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] <= $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'];
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] += $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'], $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration']++):
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['rownum'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index_prev'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] - $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index_next'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] + $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['first']      = ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] == 1);
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['last']       = ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] == $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total']);
?>
                                <?php if ($_smarty_tpl->getVariable('obj')->value->lang[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['id']==$_smarty_tpl->getVariable('obj')->value->section['lang']){?>
                                    <option value="<?php echo $_smarty_tpl->getVariable('obj')->value->lang[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['id'];?>
" selected><?php echo $_smarty_tpl->getVariable('obj')->value->lang[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['title'];?>
</option>"
                                <?php }else{ ?>
                                    <option value="<?php echo $_smarty_tpl->getVariable('obj')->value->lang[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['id'];?>
"><?php echo $_smarty_tpl->getVariable('obj')->value->lang[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['title'];?>
</option>"
                                <?php }?>
                            <?php endfor; endif; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Date Created:</label>
                        <input class="form-control" type="date" name="txtDateCreated" id="datepicker1" autocomplete="off" value="<?php echo $_smarty_tpl->getVariable('obj')->value->section['datecreated'];?>
">
                    </div>
                    <div class="form-group">
                        <label>Date Published:</label>
                        <input class="form-control" type="date" name="txtDatePublished" id="datepicker2" autocomplete="off" value="<?php echo $_smarty_tpl->getVariable('obj')->value->dateupdated;?>
">
                    </div>
                    <div class="form-group">
                        <div class="form-group">
                            <?php echo $_smarty_tpl->getVariable('obj')->value->form['object']['lblLang'];?>

                            <?php echo $_smarty_tpl->getVariable('obj')->value->form['object']['txtLang'];?>

                            <p class="help-block color-red langAlarm">
                                Lang is required!
                            </p>
                        </div>
                    </div>
                </form>
            </div>
            <div class="col-lg-6">
                <div class="form-group">
                    <label>Images input</label>
                    <input type="file" name="txtImage" form="sectionCmstypeForm">
                </div>
                <div class="form-group">
                    <img src="<?php echo $_smarty_tpl->getVariable('obj')->value->assets_public_dir;?>
/images/group/thumb/<?php echo $_smarty_tpl->getVariable('obj')->value->section['image'];?>
">
                    <input type="hidden" name="oldImage" value="<?php echo $_smarty_tpl->getVariable('obj')->value->section['image'];?>
" form="sectionCmstypeForm">
                </div>
                <div class="form-group">
                    <label>publish status :</label>
                    <div class="radio">
                        <label>
                            <input type="radio" value="1" id="optionsRadios1" name="txtPublish" form="sectionCmstypeForm" checked="checked" <?php if ($_smarty_tpl->getVariable('obj')->value->section['activity']==1){?>checked<?php }?>>
                            Enable:
                        </label>
                    </div>
                    <div class="radio">
                        <label>
                            <input type="radio" value="0" id="optionsRadios2" name="txtPublish" form="sectionCmstypeForm" <?php if ($_smarty_tpl->getVariable('obj')->value->section['activity']==0){?>checked<?php }?>>
                            Disable :
                        </label>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="form-group">
                    <label> body: </label>
                    <textarea rows="7" class="form-control" id="body" name="txtBody" form="sectionCmstypeForm"><?php echo $_smarty_tpl->getVariable('obj')->value->section['body'];?>
</textarea>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="form-group">
                    <label>description:</label>
                    <textarea rows="3" class="form-control" name="txtDescription" form="sectionCmstypeForm"><?php echo $_smarty_tpl->getVariable('obj')->value->section['description'];?>
</textarea>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="form-group">
                    <label>keyword :</label>
                    <textarea rows="3" class="form-control" name="txtKeywords" form="sectionCmstypeForm"><?php echo $_smarty_tpl->getVariable('obj')->value->section['keywords'];?>
</textarea>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="btn-group" role="group" aria-label="...">
                    <button type="submit" class="btn btn-success" name="btnSubmit" form="sectionCmstypeForm">Save</button>
                    <button type="reset" class="btn btn-warning" form="sectionCmstypeForm">Reset</button>
                    <a type="button" class="btn btn-danger" href="?r=dashboard">Exit</a>
                </div>
            </div>
        </div>
        <!-- /.row -->
    </div>
    <div role="tabpanel" class="tab-pane" id="profile">
        <div class="table-responsive">
            <table class="table table-bordered table-hover table-striped">
                <thead>
                <tr>
                    <th>row</th>
                    <th>field</th>
                    <th>title</th>
                    <th>manege</th>
                </tr>
                </thead>
                <tbody>
                <form class="form-inline"  name="field" action="" method="post">
                        
                <?php unset($_smarty_tpl->tpl_vars['smarty']->value['section']["i"]);
$_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['name'] = "i";
$_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['loop'] = is_array($_loop=$_smarty_tpl->getVariable('obj')->value->object) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['show'] = true;
$_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['max'] = $_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['loop'];
$_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['step'] = 1;
$_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['start'] = $_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['step'] > 0 ? 0 : $_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['loop']-1;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['show']) {
    $_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['total'] = $_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['loop'];
    if ($_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['total'] == 0)
        $_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['show'] = false;
} else
    $_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['total'] = 0;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['show']):

            for ($_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['index'] = $_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['start'], $_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['iteration'] = 1;
                 $_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['iteration'] <= $_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['total'];
                 $_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['index'] += $_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['step'], $_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['iteration']++):
$_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['rownum'] = $_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['iteration'];
$_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['index_prev'] = $_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['index'] - $_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['index_next'] = $_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['index'] + $_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['first']      = ($_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['iteration'] == 1);
$_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['last']       = ($_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['iteration'] == $_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['total']);
?>
                <tr>
                    <td><?php echo $_smarty_tpl->getVariable('smarty')->value['section']['i']['index']+1;?>
</td>
                    <td>

                            <input type='hidden'  class="form-control" name="object[<?php echo $_smarty_tpl->getVariable('smarty')->value['section']['i']['index']+1;?>
][id]" value="<?php echo $_smarty_tpl->getVariable('obj')->value->object[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['id'];?>
">
                            <input type='text' id='textTitle1' class="form-control" name="object[<?php echo $_smarty_tpl->getVariable('smarty')->value['section']['i']['index']+1;?>
][field]" value="<?php echo $_smarty_tpl->getVariable('obj')->value->object[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['feild'];?>
">
                    </td>
                    <td>
                        <input type='text' id='textFeild1' class="form-control" name="object[<?php echo $_smarty_tpl->getVariable('smarty')->value['section']['i']['index']+1;?>
][title]" value="<?php echo $_smarty_tpl->getVariable('obj')->value->object[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['title'];?>
">
                    </td>
                    <td>
                        <div role="group" class="btn-group">
                            <button class="btn btn-warning" name="fieldedit" type="submit" value="<?php echo $_smarty_tpl->getVariable('smarty')->value['section']['i']['index']+1;?>
">
                                <span class="glyphicon glyphicon-edit"></span>
                                Edit
                            </button>
                            <button class="btn btn-danger" name="fielddelete" type="submit" value="<?php echo $_smarty_tpl->getVariable('smarty')->value['section']['i']['index']+1;?>
" onclick="confirm('Are You Sure To Delete This Item?');">
                                <span class="glyphicon glyphicon-trash"></span>
                                Delete
                            </button>
                        </div>
                    </td>
                </tr>
                <?php endfor; endif; ?>
                </form>
                </tbody>
            </table>
        </div><!-- Page Heading -->
        <form class="form-inline" action="" method="post">
        <div id='TextBoxesGroup' style="padding: 10px;">
            <div id="TextBoxDiv1" style="padding: 10px;">
                <div class="form-group">
                    <label>Field 1 : </label><br>
                    <input type='text' id='textTitle1' class="form-control" name="object[0][field]">
                </div>
                <div class="form-group">
                    <label>title 1 : </label><br>
                    <input type='text' id='textFeild1' class="form-control" name="object[0][title]">
                </div>
            </div>
        </div>
            <button type='button' class="btn btn-success" id='addButton'>
                <span class="glyphicon glyphicon-plus-sign"></span>
                Add Field
            </button>
            <button type='button' class="btn btn-danger" id='removeButton'>
            <span class="glyphicon glyphicon-trash"></span>
                Remove
            </button>
            </span>
            <div class="form-group">
                <button type="submit" class="btn btn-success" name="btnFeild">
                    <span class="glyphicon glyphicon-send"></span>
                    Send
                </button>
            </div>
        </form>

    </div>

</div>
