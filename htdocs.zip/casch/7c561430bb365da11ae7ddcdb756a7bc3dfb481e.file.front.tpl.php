<?php /* Smarty version Smarty-3.0.5, created on 2016-05-13 19:22:57
         compiled from "view/front/tmp_hotel\front.tpl" */ ?>
<?php /*%%SmartyHeaderCode:42735735ea49540d78-52753560%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7c561430bb365da11ae7ddcdb756a7bc3dfb481e' => 
    array (
      0 => 'view/front/tmp_hotel\\front.tpl',
      1 => 1463151174,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '42735735ea49540d78-52753560',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (!is_callable('smarty_function_ctrl')) include 'protected/libs/smarty_plugins\function.ctrl.php';
?><?php echo smarty_function_ctrl(array('filename'=>"contact",'side'=>"front",'assign'=>"this"),$_smarty_tpl);?>

<header>
    <div id="Banner">
        <div id="demo" class="skdslider">
            <ul>
                <li><img src="<?php echo $_smarty_tpl->getVariable('this')->value->assets_front_dir;?>
/tmp_hotel/images/slide2.jpg" alt="full width slide1" />
                    <div class="slide-desc" id="cp1">
                        <h1><a href="#">سفری خاطره انگیز</a></h1>
                        <h2><a href="#">اطلاعات بیشتر</a></h2>
                    </div>
                </li>
                <li><img src="<?php echo $_smarty_tpl->getVariable('this')->value->assets_front_dir;?>
/tmp_hotel/images/slide0.jpg"  alt="full width slide2" />
                    <div class="slide-desc" id="cp2">
                        <h1><a href="#">سفری خاطره انگیز2</a></h1>
                        <h2><a href="#">اطلاعات بیشتر</a></h2>
                    </div>
                </li>
                <li><img src="<?php echo $_smarty_tpl->getVariable('this')->value->assets_front_dir;?>
/tmp_hotel/images/slide1.jpg"  alt="full width slide3" />
                    <div class="slide-desc" id="cp3">
                        <h1><a href="#">سفری خاطره انگیز3</a></h1>
                        <h2><a href="#">اطلاعات بیشتر</a></h2>
                    </div>
                </li>
            </ul>
        </div>
    </div><!--#Banner-->
</header>
<section>
    <div class="Wrapper">
        <div id="TempBox">
            <div class="TltBox"><a href="#">لینک مورد نظر</a>تیتر مورد نظر</div>


        </div>
        <div class="Clr"></div>
    </div>
</section>
<section>
    <div class="DarkHolder GreenHolder">
        <div id="MapBox"></div>
        <div class="Wrapper OverMap">
            <div class="TltBox"><span>با ما در تماس باشید</span>هتــــل ارگ جدیــــد</div>
            <form action="#" class="ContactForm wow fadeInRight"  data-wow-delay="0.8s" data-wow-duration="1.5s">
                <p>پیام خود را با ما در میان بگذارید</p>
                <input type="text"  value="نام شما" />
                <input type="text"  value="ایمیل شما" />
                <textarea class="CntTxt">پیام شما</textarea>
                <input type="button" class="RequestButt" value="رزرو" />
                <div class="CaptchaBox">
                    <span>کد امنیتی</span>
                    <a href="#"></a>
                    <!--<img src="<?php echo $_smarty_tpl->getVariable('this')->value->assets_front_dir;?>
/tmp_hotel/images/pathtl.png" width="300" height="50" alt="" />-->
                </div>
            </form>
            <div id="AddressBox" class="wow fadeInLeft"  data-wow-delay="0.8s" data-wow-duration="1.5s">
                <h6>پل های ارتباطی با هتل ارگ جدید</h6>
                <p><i></i>
                    کرمان ،بم ،کیلومتر 10 جاده بم زاهدان ،شهرک ارگ جدید
                </p>
                <p class="Phn"><i></i>
                    <span> 03444252472</span>
                    <span>03444252671</span>
                </p>
                <p class="Fax"><i></i>
                    <span> 03444252472</span>
                    <span>03444252671</span>
                </p>
                <p class="Eml"><i></i>
                    <span>info@a-j-hotel.ir</span>
                    <span>info@a-j-hotel.com</span>
                </p>
            </div>
            <div class="Clr"></div>
        </div>
    </div>
</section>
