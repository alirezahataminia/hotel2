<?php /* Smarty version Smarty-3.0.5, created on 2016-05-13 20:36:06
         compiled from "view/front/tmp_hotel\page.tpl" */ ?>
<?php /*%%SmartyHeaderCode:20815735fb6e8522f8-09095357%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c3d3e529ea1a9adf2a7735564a7a2d39db62e349' => 
    array (
      0 => 'view/front/tmp_hotel\\page.tpl',
      1 => 1463155564,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '20815735fb6e8522f8-09095357',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (!is_callable('smarty_function_ctrl')) include 'protected/libs/smarty_plugins\function.ctrl.php';
if (!is_callable('smarty_function_htmlSpecialDecode')) include 'protected/libs/smarty_plugins\function.htmlSpecialDecode.php';
if (!is_callable('smarty_function_stripSlash')) include 'protected/libs/smarty_plugins\function.stripSlash.php';
?><?php echo smarty_function_ctrl(array('filename'=>"page",'side'=>"front",'assign'=>"this"),$_smarty_tpl);?>


<section style="margin-top:110px;">
    <div class="Wrapper">
        <div id="TempBox">
            <div class="TltBox"><?php echo $_smarty_tpl->getVariable('this')->value->content['title'];?>
</div>
            <p>
                <img src="<?php echo $_smarty_tpl->getVariable('this')->value->assets_img;?>
/<?php echo $_smarty_tpl->getVariable('this')->value->content['image'];?>
">
            </p>
            <?php ob_start();?><?php echo smarty_function_htmlSpecialDecode(array('ts'=>$_smarty_tpl->getVariable('this')->value->content['body']),$_smarty_tpl);?>
<?php $_tmp1=ob_get_clean();?><?php echo smarty_function_stripSlash(array('ts'=>$_tmp1),$_smarty_tpl);?>


        </div>
        <div class="Clr"></div>
    </div>
</section>

