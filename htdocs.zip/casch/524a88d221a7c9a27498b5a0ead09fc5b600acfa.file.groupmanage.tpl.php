<?php /* Smarty version Smarty-3.0.5, created on 2016-05-13 20:10:57
         compiled from "view/admin/admin\groupmanage.tpl" */ ?>
<?php /*%%SmartyHeaderCode:89685735f5892bb344-79002862%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '524a88d221a7c9a27498b5a0ead09fc5b600acfa' => 
    array (
      0 => 'view/admin/admin\\groupmanage.tpl',
      1 => 1462644813,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '89685735f5892bb344-79002862',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (!is_callable('smarty_function_ctrl')) include 'protected/libs/smarty_plugins\function.ctrl.php';
?><?php echo smarty_function_ctrl(array('filename'=>"groupmanage",'side'=>"admin",'assign'=>"obj"),$_smarty_tpl);?>

<div id="page-wrapper">
    <div class="container-fluid">
        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    Dashboard <small>Statistics Overview</small>
                </h1>
                <ol class="breadcrumb">
                    <li class="active">
                        <i class="fa fa-dashboard"></i> Dashboard
                    </li>
                </ol>
            </div>
        </div>
        <!-- /.row -->
        <div class="col-xs-12">
            <?php echo $_smarty_tpl->getVariable('obj')->value->message;?>

        </div>
        <div class="col-xs-12" style="margin: 10px;">
            <a href="?r=group" class="btn btn-success">Add
                <span class="glyphicon glyphicon-plus-sign"></span>
            </a>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover table-striped">
                        <thead>
                        <tr>
                            <th>row</th>
                            <th>title</th>
                            <th>activity</th>
                            <th>swap</th>
                            <th>manege</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php unset($_smarty_tpl->tpl_vars['smarty']->value['section']['i']);
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['name'] = 'i';
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'] = is_array($_loop=$_smarty_tpl->getVariable('obj')->value->table) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show'] = true;
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['max'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'] = 1;
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'] > 0 ? 0 : $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop']-1;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show']) {
    $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'];
    if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'] == 0)
        $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show'] = false;
} else
    $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'] = 0;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show']):

            for ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'], $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] = 1;
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] <= $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'];
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] += $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'], $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration']++):
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['rownum'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index_prev'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] - $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index_next'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] + $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['first']      = ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] == 1);
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['last']       = ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] == $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total']);
?>
                            <tr>
                                <td><?php ob_start();?><?php echo $_smarty_tpl->getVariable('obj')->value->page*$_smarty_tpl->getVariable('obj')->value->item;?>
<?php $_tmp1=ob_get_clean();?><?php ob_start();?><?php echo $_smarty_tpl->getVariable('smarty')->value['section']['i']['index']+1;?>
<?php $_tmp2=ob_get_clean();?><?php ob_start();?><?php echo $_smarty_tpl->getVariable('obj')->value->item-$_tmp2;?>
<?php $_tmp3=ob_get_clean();?><?php echo $_tmp1-$_tmp3;?>
</td>
                                <td><?php echo $_smarty_tpl->getVariable('obj')->value->table[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['title'];?>
</td>
                                <td>
                                    <?php if ($_smarty_tpl->getVariable('obj')->value->table[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['activity']==1){?>
                                        <a href="?r=<?php echo $_smarty_tpl->getVariable('obj')->value->link;?>
&page=<?php echo $_smarty_tpl->getVariable('obj')->value->page;?>
&item=<?php echo $_smarty_tpl->getVariable('obj')->value->item;?>
&id=<?php echo $_smarty_tpl->getVariable('obj')->value->table[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['id'];?>
&check=0" class="btn btn-success"><span class="fa fa-check-square"></span></a>
                                    <?php }else{ ?>
                                        <a href="?r=<?php echo $_smarty_tpl->getVariable('obj')->value->link;?>
&page=<?php echo $_smarty_tpl->getVariable('obj')->value->page;?>
&item=<?php echo $_smarty_tpl->getVariable('obj')->value->item;?>
&id=<?php echo $_smarty_tpl->getVariable('obj')->value->table[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['id'];?>
&check=1" class="btn btn-danger"><span class="fa fa-times"></span></a>
                                    <?php }?>
                                </td>
                                <td>
                                    <form action="" method="post" class="form-inline">
                                        <div class="form-group">
                                            <input class="form-control input-sm" type="text" name="newSwap" value="<?php echo $_smarty_tpl->getVariable('obj')->value->table[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['order'];?>
" style="width: 60px;" autocomplete="off">
                                            <input type="hidden" value="<?php echo $_smarty_tpl->getVariable('obj')->value->table[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['order'];?>
" name="oldSwap">
                                            <input type="hidden" value="<?php echo $_smarty_tpl->getVariable('obj')->value->table[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['id'];?>
" name="swapId">
                                            <input type="submit" class="btn btn-success btn-sm" name="btnSwap" value="GO !">
                                        </div>
                                    </form>
                                </td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <a href="?r=groupedit&id=<?php echo $_smarty_tpl->getVariable('obj')->value->table[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['id'];?>
" class="btn btn-warning">
                                            <span class="glyphicon glyphicon-edit"></span>
                                            Edit
                                        </a>
                                        <button type="button" class="btn btn-info">
                                            <span class="glyphicon glyphicon-search"></span>
                                            View
                                        </button>
                                        <button type="button" class="btn btn-danger">
                                            <span class="fa fa-trash-o"></span>
                                            Delete
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endfor; endif; ?>
                        </tbody>
                    </table>
                </div>
                <div>
                    <?php echo $_smarty_tpl->getVariable('obj')->value->pagination;?>

                </div>
            </div>
        </div>
        <!-- /.row -->

    </div>
    <!-- /.container-fluid -->

</div>