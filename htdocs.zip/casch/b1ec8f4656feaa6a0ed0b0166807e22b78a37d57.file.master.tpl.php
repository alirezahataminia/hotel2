<?php /* Smarty version Smarty-3.0.5, created on 2016-05-13 20:27:00
         compiled from "view/front/tmp_hotel\master.tpl" */ ?>
<?php /*%%SmartyHeaderCode:98645735f94c4710b9-19026079%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b1ec8f4656feaa6a0ed0b0166807e22b78a37d57' => 
    array (
      0 => 'view/front/tmp_hotel\\master.tpl',
      1 => 1463154997,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '98645735f94c4710b9-19026079',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (!is_callable('smarty_function_ctrl')) include 'protected/libs/smarty_plugins\function.ctrl.php';
?><?php echo smarty_function_ctrl(array('filename'=>"master",'side'=>"front",'assign'=>"this"),$_smarty_tpl);?>

<!DOCTYPE html>
<html lang="fa-IR">
<head>
<meta charset=utf-8>
<title>  هتل ارگ جدید بم </title>
<meta name="application-name" content="default" />
<meta name="description" content=" هتل ارگ جدید بم " />
<meta name="Keywords" content="هتل ارگ جدید بم " />
<!-- google web master servers -->
<meta name="author" content="Iran Technology LTD" />
<meta name="generator" content="  هتل ارگ جدید بم " />
<!-- google web master servers end -->
<link rel="shortcut icon" href="<?php echo $_smarty_tpl->getVariable('this')->value->assets_front_dir;?>
/tmp_hotel/images/favicon.ico" type="image/x-icon" />
<link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->getVariable('this')->value->assets_front_dir;?>
/tmp_hotel/css/style.css" />
<link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->getVariable('this')->value->assets_front_dir;?>
/tmp_hotel/css/skdslider.css" />
<link rel="Stylesheet" type="text/css" href="<?php echo $_smarty_tpl->getVariable('this')->value->assets_front_dir;?>
/tmp_hotel/css/animate.css" />
<script type="text/javascript" src="<?php echo $_smarty_tpl->getVariable('this')->value->assets_front_dir;?>
/tmp_hotel/js/jquery-1.9.0.min.js"></script>
<script type="text/javascript" src="<?php echo $_smarty_tpl->getVariable('this')->value->assets_front_dir;?>
/tmp_hotel/js/skdslider.js"></script>
<script type="text/javascript" src="<?php echo $_smarty_tpl->getVariable('this')->value->assets_front_dir;?>
/tmp_hotel/js/wow.min.js"></script>
<script type="text/javascript" src="<?php echo $_smarty_tpl->getVariable('this')->value->assets_front_dir;?>
/tmp_hotel/assetfnc/jquery.fancybox.js?v=2.1.5"></script>
<link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->getVariable('this')->value->assets_front_dir;?>
/tmp_hotel/assetfnc/jquery.fancybox.css?v=2.1.5" media="screen" />

<!-- Add Button helper (this is optional) -->
<link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->getVariable('this')->value->assets_front_dir;?>
/tmp_hotel/assetfnc/helpers/jquery.fancybox-buttons.css?v=1.0.5" />
<script type="text/javascript" src="<?php echo $_smarty_tpl->getVariable('this')->value->assets_front_dir;?>
/tmp_hotel/assetfnc/helpers/jquery.fancybox-buttons.js?v=1.0.5"></script>

    <script type="text/javascript">
        $(document).ready(function() {
            //fancybox
            $('.fancybox').fancybox();

            //BackGround SlideShow
            jQuery('#demo').skdslider({'delay':6000, 'fadeSpeed': 800,'showNextPrev':true,'showPlayButton':false,'autoStart':true ,'numericNav':true});

            $('.slide-desc h1').animate({
                right: 100,
                opacity:0
            }, 000, function() {});
            $('.slide-desc h1').animate({
                right: 0,
                opacity:1
            }, 5000, function() {});

            $('.slide-desc h2').animate({
                top: 100,
                opacity:0
            }, 000, function() {});
            $('.slide-desc h2').animate({
                top: 20,
                opacity:1
            }, 5000, function() {});

            //scroll up
            $("#GoTopButt").hide();
            $(function () {
                $(window).scroll(function () {
                    if ($(this).scrollTop() > 100) {
                        $('#GoTopButt').fadeIn();
                    } else {
                        $('#GoTopButt').fadeOut();
                    }
                });
                $('#GoTopButt').click(function () {
                    $('body,html').animate({scrollTop: 0}, 800);
                    return false;
                });
            });

        });
    </script>

</head>
<body>
 <article>
  <nav>
    <div id="MenuHolder">
       <div class="Wrapper">
         <a id="Logo" href="home.html" title="هتل ارگ جدید"></a>
          <ul class="Menu">
             <li class="Current"><a href="?r=front">صفحه اصلی </a></li>
             <li><a href="?r=page&module=mod_about_us">درباره ما</a></li>
             <li><a href="home.html">امکانات هتل</a></li>
             <li><a href="home.html">گالری هتل</a></li>
             <li><a href="home.html">قیمت اتاق ها</a></li>
             <li><a href="home.html">درخواست خدمات</a></li>
             <li><a href="home.html">باشگاه مهمانان</a></li>
             <li><a class="sub" href="home.html">خدمات </a>
                <ul>
                  <li><a href="home.html">اخبار</a></li>
                  <li><a href="home.html">هواشناسی</a></li>
                  <li><a href="home.html">نظرسنجی</a></li>
                  <li><a href="home.html">خاطرات هتل</a></li>
                  <li><a href="home.html">سیستم پیام کوتاه</a></li>
                  <li><a href="home.html">پرداخت آنلاین</a></li>
                  <li><a href="home.html">سایت های مرتبط</a></li>
                  <li><a href="home.html">مجله الکترونیکی</a></li>
                </ul>
             </li>
             <li><a href="?r=page&module=mod_contact_us">تماس با ما</a></li>
          </ul>
         <div class="Clr"></div>
       </div>
    </div>
  </nav>
     <?php $_template = new Smarty_Internal_Template($_smarty_tpl->getVariable('this')->value->page, $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate();?><?php $_template->updateParentVariables(0);?><?php unset($_template);?>

  <footer>
    <div class="DarkHolder GreenHolder">
      <div class="Wrapper">
        <div id="FooterBox">
          <ul  class="wow fadeInLeft"  data-wow-delay="0.8s" data-wow-duration="1.5s">
           <li><a href="?r=page&module=mod_about_us">درباره ما</a></li>
           <li class="p1"><a href="#">امکانات هتل</a></li>
           <li class="p2"><a href="#">گالری هتل</a></li>
           <li class="p3"><a href="#">قیمت اتاق ها</a></li>
           <li class="p4"><a href="#">درخواست خدمات</a></li>
           <li class="p5"><a href="#">باشگاه مهمانان</a></li>
           <li class="p6"><a href="#">خدمات </a></li>
           <li class="p7"><a href="#">اخبار </a></li>
           <li class="p8"><a href="?r=page&module=mod_contact_us">تماس با ما</a></li>
          </ul>
        </div>
        <div class="FooterLine TempBorder">
          <span> © 2015 Arg Hotel. All Rights Reserved.</span>
          <span><a id="irantech5"  href="http://www.iran-tech.com" target="_blank" >طراحی سایت : ایران تکنولوژی</a></span>
          <span><div id="Stat"></div></span>
        </div>
        <div class="Clr"></div>
      </div>
    </div>
  </footer>
  </article>
  <script>
	new WOW().init();
  </script>
 </body>
</html>