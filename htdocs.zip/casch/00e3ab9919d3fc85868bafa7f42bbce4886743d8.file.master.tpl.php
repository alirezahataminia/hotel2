<?php /* Smarty version Smarty-3.0.5, created on 2016-05-13 21:01:15
         compiled from "view/admin/admin\master.tpl" */ ?>
<?php /*%%SmartyHeaderCode:313757360153818cc0-44860267%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '00e3ab9919d3fc85868bafa7f42bbce4886743d8' => 
    array (
      0 => 'view/admin/admin\\master.tpl',
      1 => 1463157074,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '313757360153818cc0-44860267',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (!is_callable('smarty_function_ctrl')) include 'protected/libs/smarty_plugins\function.ctrl.php';
?><?php echo smarty_function_ctrl(array('filename'=>"master",'side'=>"admin",'assign'=>"this"),$_smarty_tpl);?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Bootstrap 101 Template</title>

    <!-- Bootstrap -->
    <link href="<?php echo $_smarty_tpl->getVariable('this')->value->assets_admin_dir;?>
/admin/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo $_smarty_tpl->getVariable('this')->value->assets_admin_dir;?>
/admin/css/bootstrap-rtl.min_.css" rel="stylesheet">
    <link href="<?php echo $_smarty_tpl->getVariable('this')->value->assets_admin_dir;?>
/admin/css/jquery-ui.css" rel="stylesheet">
    <link href="<?php echo $_smarty_tpl->getVariable('this')->value->assets_admin_dir;?>
/admin/css/style.css" rel="stylesheet">
    <link href="<?php echo $_smarty_tpl->getVariable('this')->value->assets_public_dir;?>
/css/font-awesome.min.css" rel="stylesheet">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="<?php echo $_smarty_tpl->getVariable('this')->value->assets_admin_dir;?>
/admin/js/html5shiv.min.js"></script>
    <script src="<?php echo $_smarty_tpl->getVariable('this')->value->assets_admin_dir;?>
/admin/js/respond.min.js"></script>
    <![endif]-->
</head>
<body>
<div class="navbar navbar-inverse navbar-fixed-top">
    <a class="navbar-brand" href="?r=front">
        سیستم مدیریت محتوا
    </a>
</div>
<div class="navbar navbar-inverse navbar-fixed-left">
    <img src="<?php echo $_smarty_tpl->getVariable('this')->value->assets_admin_dir;?>
/admin/images/user.jpg" class="img-responsive img-circle">
    <ul class="nav navbar-nav">
        <li><a href="?r=sectionmanage&page=1&item=10">بخش ها</a></li>
        <li><a href="?r=groupmanage&page=1&item=10">گروه ها</a></li>
        <li><a href="?r=contentmanage&page=1&item=10">محتوا</a></li>
    </ul>
</div>
<div class="container content">
    <div class="row">
        <?php $_template = new Smarty_Internal_Template($_smarty_tpl->getVariable('this')->value->page, $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate();?><?php $_template->updateParentVariables(0);?><?php unset($_template);?>
    </div>
</div>

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->

<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="<?php echo $_smarty_tpl->getVariable('this')->value->assets_admin_dir;?>
/admin/js/jquery.min.js"></script>
    <script src="<?php echo $_smarty_tpl->getVariable('this')->value->assets_admin_dir;?>
/admin/js/jquery-ui.min.js"></script>
<script src="<?php echo $_smarty_tpl->getVariable('this')->value->assets_public_dir;?>
/ckeditor/ckeditor.js"></script>
<script src="<?php echo $_smarty_tpl->getVariable('this')->value->assets_admin_dir;?>
/admin/js/ckhandler.js"></script>
<script src="<?php echo $_smarty_tpl->getVariable('this')->value->assets_admin_dir;?>
/admin/js/bootstrap-filestyle.min.js"></script>

<script src="<?php echo $_smarty_tpl->getVariable('this')->value->assets_admin_dir;?>
/admin/js/bootstrap.min.js"></script>
<script src="<?php echo $_smarty_tpl->getVariable('this')->value->assets_admin_dir;?>
/admin/js/authrn.js"></script>

    <script>
        $(function() {
            $( "#accordion" ).accordion({
                collapsible: true
                ,active: false
            });
            $( "#accordion2" ).accordion({
                collapsible: true
                ,active: false
            });
        });
        $(":file").filestyle({buttonName: "btn-fileImage",buttonBefore: true});
        $(function() {
            $( "#datepicker1" ).datepicker();
            $( "#datepicker2" ).datepicker();
        });

    </script>
    
</body>
</html>