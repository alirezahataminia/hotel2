<?php /* Smarty version Smarty-3.0.5, created on 2016-05-13 20:19:48
         compiled from "view/admin/admin\sectionedit.tpl" */ ?>
<?php /*%%SmartyHeaderCode:230115735f79c800631-48180073%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '25800f6c3f05a2b172726302d1f8a86695a8e1ba' => 
    array (
      0 => 'view/admin/admin\\sectionedit.tpl',
      1 => 1463049806,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '230115735f79c800631-48180073',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (!is_callable('smarty_function_ctrl')) include 'protected/libs/smarty_plugins\function.ctrl.php';
?><?php echo smarty_function_ctrl(array('filename'=>"sectionedit",'side'=>"admin",'assign'=>"obj"),$_smarty_tpl);?>

<ul class="nav nav-tabs" role="tablist">
    <li role="presentation" class="active"><a href="#home" aria-controls="home" role="tab" data-toggle="tab">Section Edit</a></li>
    <li role="presentation"><a href="#profile" aria-controls="profile" role="tab" data-toggle="tab">
            sub Group
        </a></li>
</ul>
<div class="tab-content">
    <div role="tabpanel" class="tab-pane active" id="home">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    section <small>add new section</small>
                </h1>
                <ol class="breadcrumb">
                    <li class="active">
                        <i class="fa fa-dashboard"></i> Dashboard
                    </li>
                </ol>
            </div>
        </div>
        <?php echo $_smarty_tpl->getVariable('obj')->value->message;?>

        <!-- /.row -->
        <div class="row">
            <div class="col-lg-12">
                <div class="col-lg-6">
                    <div class="btn-group" role="group" aria-label="...">
                        <button type="submit" class="btn btn-success" name="btnSubmit" form="sectionCmstypeForm">Save</button>
                        <button type="reset" class="btn btn-warning" form="sectionCmstypeForm">Reset</button>
                        <a type="button" class="btn btn-danger" href="?r=sectionmanage">Exit</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <form action="" method="post" id="sectionCmstypeForm" class="frm" enctype="multipart/form-data">
                    <input type="hidden" name="txtOrder" value="<?php echo $_smarty_tpl->getVariable('obj')->value->section['order'];?>
">
                    <input type="hidden" value="<?php echo $_smarty_tpl->getVariable('obj')->value->id;?>
" name="txtId">
                    <div class="form-group">
                        <label class="lblTitle">Title:</label>
                        <input class="form-control txtTitle" type="text" name="txtTitle" id="txtTitle" value="<?php echo $_smarty_tpl->getVariable('obj')->value->section['title'];?>
">
                        <p class="help-block color-red titleAlarm">
                            Title is required!
                        </p>
                    </div>
                    <div class="form-group">
                        <label>Module :</label>
                        <input class="form-control" type="text" name="txtModule" value="<?php echo $_smarty_tpl->getVariable('obj')->value->section['module'];?>
">
                    </div>
                    <div class="form-group">
                        <label>Language :</label>
                        <select class="form-control" name="txtLang">
                            <?php unset($_smarty_tpl->tpl_vars['smarty']->value['section']['i']);
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['name'] = 'i';
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'] = is_array($_loop=$_smarty_tpl->getVariable('obj')->value->lang) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show'] = true;
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['max'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'] = 1;
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'] > 0 ? 0 : $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop']-1;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show']) {
    $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'];
    if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'] == 0)
        $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show'] = false;
} else
    $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'] = 0;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show']):

            for ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'], $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] = 1;
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] <= $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'];
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] += $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'], $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration']++):
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['rownum'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index_prev'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] - $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index_next'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] + $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['first']      = ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] == 1);
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['last']       = ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] == $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total']);
?>
                                <?php if ($_smarty_tpl->getVariable('obj')->value->lang[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['id']==$_smarty_tpl->getVariable('obj')->value->section['lang']){?>
                                    <option value="<?php echo $_smarty_tpl->getVariable('obj')->value->lang[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['id'];?>
" selected><?php echo $_smarty_tpl->getVariable('obj')->value->lang[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['title'];?>
</option>"
                                <?php }else{ ?>
                                    <option value="<?php echo $_smarty_tpl->getVariable('obj')->value->lang[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['id'];?>
"><?php echo $_smarty_tpl->getVariable('obj')->value->lang[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['title'];?>
</option>"
                                <?php }?>
                            <?php endfor; endif; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Date Created:</label>
                        <input class="form-control" type="date" name="txtDateCreated" id="datepicker1" autocomplete="off" value="<?php echo $_smarty_tpl->getVariable('obj')->value->section['datecreated'];?>
">
                    </div>
                    <div class="form-group">
                        <label>Date Published:</label>
                        <input class="form-control" type="date" name="txtDatePublished" id="datepicker2" autocomplete="off" value="<?php echo $_smarty_tpl->getVariable('obj')->value->dateupdated;?>
">
                    </div>
                    <div class="form-group">
                        <div class="form-group">
                            <?php echo $_smarty_tpl->getVariable('obj')->value->form['object']['lblLang'];?>

                            <?php echo $_smarty_tpl->getVariable('obj')->value->form['object']['txtLang'];?>

                            <p class="help-block color-red langAlarm">
                                Lang is required!
                            </p>
                        </div>
                    </div>
                </form>
            </div>
            <div class="col-lg-6">
                <div class="form-group">
                    <label>Images input</label>
                    <input type="file" name="txtImage" form="sectionCmstypeForm">
                </div>
                <div class="form-group">
                    <img src="<?php echo $_smarty_tpl->getVariable('obj')->value->assets_public_dir;?>
/images/section/thumb/<?php echo $_smarty_tpl->getVariable('obj')->value->section['image'];?>
">
                    <input type="hidden" name="oldImage" value="<?php echo $_smarty_tpl->getVariable('obj')->value->section['image'];?>
" form="sectionCmstypeForm">
                </div>
                <div class="form-group">
                    <label>publish status :</label>
                    <div class="radio">
                        <label>
                            <input type="radio" value="1" id="optionsRadios1" name="txtPublish" form="sectionCmstypeForm" checked="checked" <?php if ($_smarty_tpl->getVariable('obj')->value->section['activity']==1){?>checked<?php }?>>
                            Enable:
                        </label>
                    </div>
                    <div class="radio">
                        <label>
                            <input type="radio" value="0" id="optionsRadios2" name="txtPublish" form="sectionCmstypeForm" <?php if ($_smarty_tpl->getVariable('obj')->value->section['activity']==0){?>checked<?php }?>>
                            Disable :
                        </label>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="form-group">
                    <label> body: </label>
                    <textarea rows="7" class="form-control" id="body" name="txtBody" form="sectionCmstypeForm"><?php echo $_smarty_tpl->getVariable('obj')->value->section['body'];?>
</textarea>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="form-group">
                    <label>description:</label>
                    <textarea rows="3" class="form-control" name="txtDescription" form="sectionCmstypeForm"><?php echo $_smarty_tpl->getVariable('obj')->value->section['description'];?>
</textarea>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="form-group">
                    <label>keyword :</label>
                    <textarea rows="3" class="form-control" name="txtKeywords" form="sectionCmstypeForm"><?php echo $_smarty_tpl->getVariable('obj')->value->section['keywords'];?>
</textarea>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="btn-group" role="group" aria-label="...">
                    <button type="submit" class="btn btn-success" name="btnSubmit" form="sectionCmstypeForm">Save</button>
                    <button type="reset" class="btn btn-warning" form="sectionCmstypeForm">Reset</button>
                    <a class="btn btn-danger" href="?r=sectionmanage">Exit</a>
                </div>
            </div>
        </div>
        <!-- /.row -->
    </div>
    <div role="tabpanel" class="tab-pane" id="profile"> <!-- Page Heading -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Dashboard <small>Statistics Overview</small>
                        </h1>
                        <ol class="breadcrumb">
                            <li class="active">
                                <i class="fa fa-dashboard"></i> Dashboard
                            </li>
                        </ol>
                    </div>
                </div>
                <!-- /.row -->
                <div class="col-xs-12">
                    <?php echo $_smarty_tpl->getVariable('obj')->value->message;?>

                </div>
                <div class="col-xs-12" style="margin: 10px;">
                    <a href="?r=group" class="btn btn-success">Add
                        <span class="glyphicon glyphicon-plus-sign"></span>
                    </a>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover table-striped">
                                <thead>
                                <tr>
                                    <th>row</th>
                                    <th>title</th>
                                    <th>activity</th>
                                    <th>swap</th>
                                    <th>manege</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php unset($_smarty_tpl->tpl_vars['smarty']->value['section']['i']);
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['name'] = 'i';
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'] = is_array($_loop=$_smarty_tpl->getVariable('obj')->value->table) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show'] = true;
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['max'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'] = 1;
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'] > 0 ? 0 : $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop']-1;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show']) {
    $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'];
    if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'] == 0)
        $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show'] = false;
} else
    $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'] = 0;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show']):

            for ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'], $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] = 1;
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] <= $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'];
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] += $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'], $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration']++):
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['rownum'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index_prev'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] - $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index_next'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] + $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['first']      = ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] == 1);
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['last']       = ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] == $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total']);
?>
                                    <tr>
                                        <td><?php ob_start();?><?php echo $_smarty_tpl->getVariable('obj')->value->page*$_smarty_tpl->getVariable('obj')->value->item;?>
<?php $_tmp1=ob_get_clean();?><?php ob_start();?><?php echo $_smarty_tpl->getVariable('smarty')->value['section']['i']['index']+1;?>
<?php $_tmp2=ob_get_clean();?><?php ob_start();?><?php echo $_smarty_tpl->getVariable('obj')->value->item-$_tmp2;?>
<?php $_tmp3=ob_get_clean();?><?php echo $_tmp1-$_tmp3;?>
</td>
                                        <td><?php echo $_smarty_tpl->getVariable('obj')->value->table[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['title'];?>
</td>
                                        <td>
                                            <?php if ($_smarty_tpl->getVariable('obj')->value->table[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['activity']==1){?>
                                                <a href="?r=<?php echo $_smarty_tpl->getVariable('obj')->value->link;?>
&page=<?php echo $_smarty_tpl->getVariable('obj')->value->page;?>
&item=<?php echo $_smarty_tpl->getVariable('obj')->value->item;?>
&id=<?php echo $_smarty_tpl->getVariable('obj')->value->table[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['id'];?>
&check=0" class="btn btn-success"><span class="fa fa-check-square"></span></a>
                                            <?php }else{ ?>
                                                <a href="?r=<?php echo $_smarty_tpl->getVariable('obj')->value->link;?>
&page=<?php echo $_smarty_tpl->getVariable('obj')->value->page;?>
&item=<?php echo $_smarty_tpl->getVariable('obj')->value->item;?>
&id=<?php echo $_smarty_tpl->getVariable('obj')->value->table[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['id'];?>
&check=1" class="btn btn-danger"><span class="fa fa-times"></span></a>
                                            <?php }?>
                                        </td>
                                        <td>
                                            <form action="" method="post" class="form-inline">
                                                <div class="form-group">
                                                    <input class="form-control input-sm" type="text" name="newSwap" value="<?php echo $_smarty_tpl->getVariable('obj')->value->table[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['order'];?>
" style="width: 60px;" autocomplete="off">
                                                    <input type="hidden" value="<?php echo $_smarty_tpl->getVariable('obj')->value->table[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['order'];?>
" name="oldSwap">
                                                    <input type="hidden" value="<?php echo $_smarty_tpl->getVariable('obj')->value->table[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['id'];?>
" name="swapId">
                                                    <input type="submit" class="btn btn-success btn-sm" name="btnSwap" value="GO !">
                                                </div>
                                            </form>
                                        </td>
                                        <td>
                                            <div class="btn-group" role="group">
                                                <a href="?r=groupedit&id=<?php echo $_smarty_tpl->getVariable('obj')->value->table[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['id'];?>
" class="btn btn-warning">
                                                    <span class="glyphicon glyphicon-edit"></span>
                                                    Edit
                                                </a>
                                                <button type="button" class="btn btn-info">
                                                    <span class="glyphicon glyphicon-search"></span>
                                                    View
                                                </button>
                                                <button type="button" class="btn btn-danger">
                                                    <span class="fa fa-trash-o"></span>
                                                    Delete
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endfor; endif; ?>
                                </tbody>
                            </table>
                        </div>
                        <div>
                            <?php echo $_smarty_tpl->getVariable('obj')->value->pagination;?>

                        </div>
                    </div>
                </div>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
    </div>

</div>
