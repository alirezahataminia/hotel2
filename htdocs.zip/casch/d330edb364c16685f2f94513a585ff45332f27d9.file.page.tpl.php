<?php /* Smarty version Smarty-3.0.5, created on 2016-05-13 21:33:54
         compiled from "view/admin/admin\page.tpl" */ ?>
<?php /*%%SmartyHeaderCode:19232573608fabd9fa5-21324498%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd330edb364c16685f2f94513a585ff45332f27d9' => 
    array (
      0 => 'view/admin/admin\\page.tpl',
      1 => 1463159032,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '19232573608fabd9fa5-21324498',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (!is_callable('smarty_function_ctrl')) include 'protected/libs/smarty_plugins\function.ctrl.php';
?><?php echo smarty_function_ctrl(array('filename'=>"page",'side'=>"admin",'assign'=>"obj"),$_smarty_tpl);?>

<ul class="nav nav-tabs" role="tablist">
    <li role="presentation" class="active"><a href="#home" aria-controls="home" role="tab" data-toggle="tab">ویرایش محتوا</a></li>
    <li role="presentation"><a href="#profile" aria-controls="profile" role="tab" data-toggle="tab">
فیلد های ویژه        </a></li>
</ul>
<div class="tab-content">
    <div role="tabpanel" class="tab-pane active" id="home">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    مدیریت محتوا <small>ویرایش محتوا</small>
                </h1>
                <ol class="breadcrumb">
                    <li class="active">
                        <i class="fa fa-dashboard"></i> Dashboard
                    </li>
                </ol>
            </div>
        </div>
        <?php echo $_smarty_tpl->getVariable('obj')->value->message;?>

        <!-- /.row -->
        <div class="row">
            <div class="col-lg-12">
                <div class="col-lg-6">
                    <div class="btn-group" role="group" aria-label="...">
                        <button type="submit" class="btn btn-success" name="btnSubmit" form="sectionCmstypeForm">ذخیره</button>
                        <button type="reset" class="btn btn-warning" form="sectionCmstypeForm">بازنشانی</button>
                        <a type="button" class="btn btn-danger" href="?r=dashboard">خروج</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <form action="" method="post" id="sectionCmstypeForm" class="frm" enctype="multipart/form-data">
                    <input type="hidden" value="<?php echo $_smarty_tpl->getVariable('obj')->value->id;?>
" name="txtId">
                    <input type="hidden" value="<?php echo $_smarty_tpl->getVariable('obj')->value->section['parent'];?>
" name="txtParent">
                    <div class="form-group">
                        <label class="lblTitle">عنوان</label>
                        <input class="form-control txtTitle" type="text" name="txtTitle" id="txtTitle" value="<?php echo $_smarty_tpl->getVariable('obj')->value->section['title'];?>
">
                        <p class="help-block color-red titleAlarm">
                            فیلد عنوان نباید خالی باشد
                        </p>
                    </div>
                    <div class="form-group">
                        <input class="form-control" type="hidden" name="txtModule" value="<?php echo $_smarty_tpl->getVariable('obj')->value->section['module'];?>
">
                    </div>
                    <div class="form-group">
                        <input type="hidden" name="txtLang" value="<?php echo $_smarty_tpl->getVariable('obj')->value->section['parent'];?>
>
                    </div>
                    <div class="form-group">
                        <input class="form-control" type="hidden" name="txtDateCreated" id="datepicker1" autocomplete="off" value="<?php echo $_smarty_tpl->getVariable('obj')->value->section['datecreated'];?>
">
                    </div>
                    <div class="form-group">
                        <input class="form-control" type="hidden" name="txtDatePublished" id="datepicker2" autocomplete="off" value="<?php echo $_smarty_tpl->getVariable('obj')->value->dateupdated;?>
">
                    </div>
                    <div class="form-group">
                        <div class="form-group">
                            <?php echo $_smarty_tpl->getVariable('obj')->value->form['object']['lblLang'];?>

                            <?php echo $_smarty_tpl->getVariable('obj')->value->form['object']['txtLang'];?>

                            <p class="help-block color-red langAlarm">
                                Lang is required!
                            </p>
                        </div>
                    </div>
                </form>
            </div>
            <div class="col-lg-6">
                <div class="form-group">
                    <label>درج تصویر</label>
                    <input type="file" name="txtImage" form="sectionCmstypeForm">
                </div>
                <div class="form-group">
                    <img src="<?php echo $_smarty_tpl->getVariable('obj')->value->assets_public_dir;?>
/images/content/thumb/<?php echo $_smarty_tpl->getVariable('obj')->value->section['image'];?>
">
                    <input type="hidden" name="oldImage" value="<?php echo $_smarty_tpl->getVariable('obj')->value->section['image'];?>
" form="sectionCmstypeForm">
                </div>
                <div class="form-group" style="display: none;">
                    <label>انتشار</label>
                    <div class="radio">
                        <label>
                            <input type="radio" value="1" id="optionsRadios1" name="txtPublish" form="sectionCmstypeForm" checked="checked" <?php if ($_smarty_tpl->getVariable('obj')->value->section['activity']==1){?>checked<?php }?>>
                            Enable:
                        </label>
                    </div>
                    <div class="radio">
                        <label>
                            <input type="radio" value="0" id="optionsRadios2" name="txtPublish" form="sectionCmstypeForm" <?php if ($_smarty_tpl->getVariable('obj')->value->section['activity']==0){?>checked<?php }?>>
                            Disable :
                        </label>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="form-group">
                    <label> متن: </label>
                    <textarea rows="7" class="form-control" id="body" name="txtBody" form="sectionCmstypeForm"><?php echo $_smarty_tpl->getVariable('obj')->value->section['body'];?>
</textarea>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="form-group">
                    <label>توضیحات:</label>
                    <textarea rows="3" class="form-control" name="txtDescription" form="sectionCmstypeForm"><?php echo $_smarty_tpl->getVariable('obj')->value->section['description'];?>
</textarea>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="form-group">
                    <label>کلمات کلیدی :</label>
                    <textarea rows="3" class="form-control" name="txtKeywords" form="sectionCmstypeForm"><?php echo $_smarty_tpl->getVariable('obj')->value->section['keywords'];?>
</textarea>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="btn-group" role="group" aria-label="...">
                    <button type="submit" class="btn btn-success" name="btnSubmit" form="sectionCmstypeForm">Save</button>
                    <button type="reset" class="btn btn-warning" form="sectionCmstypeForm">Reset</button>
                    <a type="button" class="btn btn-danger" href="?r=dashboard">Exit</a>
                </div>
            </div>
        </div>
        <!-- /.row -->
    </div>

    <div role="tabpanel" class="tab-pane" id="profile"> <!-- Page Heading -->
        <?php if (!empty($_smarty_tpl->getVariable('obj')->value->object)){?>
        <form class="form-inline" action="" method="post">
            <?php unset($_smarty_tpl->tpl_vars['smarty']->value['section']["i"]);
$_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['name'] = "i";
$_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['loop'] = is_array($_loop=$_smarty_tpl->getVariable('obj')->value->object) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['show'] = true;
$_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['max'] = $_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['loop'];
$_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['step'] = 1;
$_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['start'] = $_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['step'] > 0 ? 0 : $_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['loop']-1;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['show']) {
    $_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['total'] = $_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['loop'];
    if ($_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['total'] == 0)
        $_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['show'] = false;
} else
    $_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['total'] = 0;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['show']):

            for ($_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['index'] = $_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['start'], $_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['iteration'] = 1;
                 $_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['iteration'] <= $_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['total'];
                 $_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['index'] += $_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['step'], $_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['iteration']++):
$_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['rownum'] = $_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['iteration'];
$_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['index_prev'] = $_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['index'] - $_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['index_next'] = $_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['index'] + $_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['first']      = ($_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['iteration'] == 1);
$_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['last']       = ($_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['iteration'] == $_smarty_tpl->tpl_vars['smarty']->value['section']["i"]['total']);
?>
                <?php $_smarty_tpl->tpl_vars['value'] = new Smarty_variable('', null, null);?>
                <?php unset($_smarty_tpl->tpl_vars['smarty']->value['section']["j"]);
$_smarty_tpl->tpl_vars['smarty']->value['section']["j"]['name'] = "j";
$_smarty_tpl->tpl_vars['smarty']->value['section']["j"]['loop'] = is_array($_loop=$_smarty_tpl->getVariable('obj')->value->values) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$_smarty_tpl->tpl_vars['smarty']->value['section']["j"]['show'] = true;
$_smarty_tpl->tpl_vars['smarty']->value['section']["j"]['max'] = $_smarty_tpl->tpl_vars['smarty']->value['section']["j"]['loop'];
$_smarty_tpl->tpl_vars['smarty']->value['section']["j"]['step'] = 1;
$_smarty_tpl->tpl_vars['smarty']->value['section']["j"]['start'] = $_smarty_tpl->tpl_vars['smarty']->value['section']["j"]['step'] > 0 ? 0 : $_smarty_tpl->tpl_vars['smarty']->value['section']["j"]['loop']-1;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']["j"]['show']) {
    $_smarty_tpl->tpl_vars['smarty']->value['section']["j"]['total'] = $_smarty_tpl->tpl_vars['smarty']->value['section']["j"]['loop'];
    if ($_smarty_tpl->tpl_vars['smarty']->value['section']["j"]['total'] == 0)
        $_smarty_tpl->tpl_vars['smarty']->value['section']["j"]['show'] = false;
} else
    $_smarty_tpl->tpl_vars['smarty']->value['section']["j"]['total'] = 0;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']["j"]['show']):

            for ($_smarty_tpl->tpl_vars['smarty']->value['section']["j"]['index'] = $_smarty_tpl->tpl_vars['smarty']->value['section']["j"]['start'], $_smarty_tpl->tpl_vars['smarty']->value['section']["j"]['iteration'] = 1;
                 $_smarty_tpl->tpl_vars['smarty']->value['section']["j"]['iteration'] <= $_smarty_tpl->tpl_vars['smarty']->value['section']["j"]['total'];
                 $_smarty_tpl->tpl_vars['smarty']->value['section']["j"]['index'] += $_smarty_tpl->tpl_vars['smarty']->value['section']["j"]['step'], $_smarty_tpl->tpl_vars['smarty']->value['section']["j"]['iteration']++):
$_smarty_tpl->tpl_vars['smarty']->value['section']["j"]['rownum'] = $_smarty_tpl->tpl_vars['smarty']->value['section']["j"]['iteration'];
$_smarty_tpl->tpl_vars['smarty']->value['section']["j"]['index_prev'] = $_smarty_tpl->tpl_vars['smarty']->value['section']["j"]['index'] - $_smarty_tpl->tpl_vars['smarty']->value['section']["j"]['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']["j"]['index_next'] = $_smarty_tpl->tpl_vars['smarty']->value['section']["j"]['index'] + $_smarty_tpl->tpl_vars['smarty']->value['section']["j"]['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']["j"]['first']      = ($_smarty_tpl->tpl_vars['smarty']->value['section']["j"]['iteration'] == 1);
$_smarty_tpl->tpl_vars['smarty']->value['section']["j"]['last']       = ($_smarty_tpl->tpl_vars['smarty']->value['section']["j"]['iteration'] == $_smarty_tpl->tpl_vars['smarty']->value['section']["j"]['total']);
?>

                    <?php ob_start();?><?php echo $_smarty_tpl->getVariable('obj')->value->object[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['id'];?>
<?php $_tmp1=ob_get_clean();?><?php if ($_smarty_tpl->getVariable('obj')->value->values[$_smarty_tpl->getVariable('smarty')->value['section']['j']['index']]['object_id']==$_tmp1){?>
                        <?php $_smarty_tpl->tpl_vars['value'] = new Smarty_variable($_smarty_tpl->getVariable('obj')->value->values[$_smarty_tpl->getVariable('smarty')->value['section']['j']['index']]['value'], null, null);?>
                    <?php }?>
                <?php endfor; endif; ?>
                <div class="form-group">
                    <label for="exampleInputName2"><?php echo $_smarty_tpl->getVariable('obj')->value->object[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['title'];?>
</label>

                    <input type="text" value="<?php echo $_smarty_tpl->getVariable('value')->value;?>
" class="form-control" id="exampleInputName2" placeholder="Jane Doe" name="values[<?php echo $_smarty_tpl->getVariable('smarty')->value['section']['i']['index'];?>
]">
                    <input type="hidden" value="<?php echo $_smarty_tpl->getVariable('obj')->value->object[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['id'];?>
" name="object_id[<?php echo $_smarty_tpl->getVariable('smarty')->value['section']['i']['index'];?>
]">
                </div>
            <?php endfor; endif; ?>
            <input type="submit" name="btnFeild" class="btn btn-success">
        </form>
        <?php }else{ ?>
        فیلد ویژه ای یافت نشد!
    </div>

<?php }?>
</div>
