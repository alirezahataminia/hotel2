<?php /* Smarty version Smarty-3.0.5, created on 2016-05-13 21:13:11
         compiled from "view/admin/admin\front.tpl" */ ?>
<?php /*%%SmartyHeaderCode:224805736041f6c4c09-69234687%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2b331c77c06e670afafbfb0c66b7097cc761cd6d' => 
    array (
      0 => 'view/admin/admin\\front.tpl',
      1 => 1463157789,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '224805736041f6c4c09-69234687',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (!is_callable('smarty_function_ctrl')) include 'protected/libs/smarty_plugins\function.ctrl.php';
?><?php echo smarty_function_ctrl(array('filename'=>"front",'side'=>"admin",'assign'=>"this"),$_smarty_tpl);?>

<div class="col-xs-12" style="margin-top: 20px;">
<div class="col-xs-4">
    <div class="panel panel-primary">
        <div class="panel-heading">
            <h3 class="panel-title">تماس با ما</h3>
        </div>
        <div class="panel-body">
            <a href="?r=page&module=mod_contact_us">
                ویرایش تماس با ما
                </a>
        </div>
    </div>

</div>
    <div class="col-xs-4">
    <div class="panel panel-primary">
        <div class="panel-heading">
            <h3 class="panel-title">درباره ما</h3>
        </div>
        <div class="panel-body">
            <a href="?r=page&module=mod_about_us">
                ویرایش درباره ما
                </a>
        </div>
    </div>

</div>
</div>
