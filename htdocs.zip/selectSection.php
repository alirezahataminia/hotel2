<?php

include 'protected/configs/config.php';


$section = DatabaseHandler::GetAll("select * from section_cmstype WHERE lang=$_POST[selectLang] && parent=0");
//foreach ($section as $section2)
//{
//    echo "<option value='$section2[id]'>".$section2[title]."</option>";
    echo "<option>d</option>";
//}

