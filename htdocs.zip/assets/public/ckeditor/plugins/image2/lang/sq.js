/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'sq', {
	alt: 'Tekst Alternativ',
	btnUpload: 'Dërgo në server',
	captioned: 'Captioned image', // MISSING
	captionPlaceholder: 'Caption', // MISSING
	infoTab: 'Informacione mbi Fotografinë',
	lockRatio: 'Mbyll Racionin',
	menu: 'Karakteristikat e Fotografisë',
	pathName: 'foto',
	pathNameCaption: 'caption', // MISSING
	resetSize: 'Rikthe Madhësinë',
	resizer: 'Click and drag to resize', // MISSING
	title: 'Karakteristikat e Fotografisë',
	uploadTab: 'Ngarko',
	urlMissing: 'Mungon URL e burimit të fotografisë.'
} );
