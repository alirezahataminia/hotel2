
$(document).ready(function() {
    var counter = 1;
    $(".objC").css("padding", "10px");
    $("#addButton").click(function () {

        if(counter>10){
            alert("Only 10 textboxes allow");
            return false;
        }

        var newTextBoxDiv = $(document.createElement('div'))
            .attr("id", 'TextBoxDiv' + counter);

        newTextBoxDiv.after().html('<div class="form-group"><label>Field '+ (counter+1) + ' : </label><br>' +
            '<input type="text" name="object[' + counter +
            '][field]" id="textbox[' + counter + ']" value="" class="form-control"></div><div class="form-group"><label>title '+ (counter+1) + ' : </label><br>' +
            '<input type="text" name="object[' + counter +
            '][title]" id="textbox' + counter + '" value="" class="form-control"></div>');

        newTextBoxDiv.appendTo("#TextBoxesGroup");


        counter++;
    });

    $("#removeButton").click(function () {
        if(counter==1){
            alert("No more textbox to remove");
            return false;
        }

        counter--;

        $("#TextBoxDiv" + counter).remove();

    });

    $("#getButtonValue").click(function () {

        var msg = '';
        for(i=1; i<counter; i++){
            msg += "\n Textbox #" + i + " : " + $('#textbox' + i).val();
        }
        alert(msg);
    });




    $(".titleAlarm").hide();
    $(".sectionAlarm").hide();
    $(".langAlarm").hide();
    $('.frm').submit(function(event) {
        var txtTitle = $('.txtTitle').val();
        var txtSection = $('.txtSection').val();
        var txtLang = $('#txtLang').val();
        if (txtTitle == '') {
            event.preventDefault();
            $("html,body").animate({scrollTop:0}, "slow");
            $(".titleAlarm").show("slow");
            $(".txtTitle").addClass("border-red");
            $(".lblTitle").addClass("color-red");
        }
        if (txtSection == 0) {
            event.preventDefault();
            $("html,body").animate({scrollTop:0}, "slow");
            $(".sectionAlarm").show("slow");
            $(".txtSection").addClass("border-red");
            $(".lblSection").addClass("color-red");
        }
        if (txtLang == 0) {
            event.preventDefault();
            $("html,body").animate({scrollTop:0}, "slow");
            $(".langAlarm").show("slow");
            $("#txtLang").addClass("border-red");
            $(".lblLang").addClass("color-red");
        }
    });
    $(".txtTitle").keyup(function(){
        var txtTitle =  $('.txtTitle').val();
        if(txtTitle != '')
        {
            $(".titleAlarm").hide("slow");
            $(".txtTitle").removeClass("border-red");
            $(".lblTitle").removeClass("color-red");
        }
        else
        {
            $(".txtTitle").addClass("border-red");
            $(".lblTitle").addClass("color-red");
        }
    });
    $(".txtSection").change(function(){
        var txtSection =  $('.txtSection').val();
        if(txtSection != 0)
        {
            $(".sectionAlarm").hide("slow");
            $(".txtSection").removeClass("border-red");
            $(".lblSection").removeClass("color-red");
        }
        else
        {
            $(".txtSection").addClass("border-red");
            $(".lblSection").addClass("color-red");
        }
    });
    $('#selectSection').change(function(){
        $(document).ajaxStart(function(){
            $("#loading").css("display", "block");
        });
        $(document).ajaxComplete(function(){
            $("#loading").css("display", "none");
        });
        selectSection = $('#selectSection').val();
        $.post(
            '../ajax/selectGroup.php'
            ,{selectSection:selectSection}
            ,function(data)
            {
                $('#selectGroup').html(data);
            }
        );

    });
    $('#selectLang').change(function(){
        $(document).ajaxStart(function(){
            $("#loading").css("display", "block");
        });
        $(document).ajaxComplete(function(){
            $("#loading").css("display", "none");
        });
        selectLang = $('#selectLang').val();
        $.post(
            '../../../../selectSection.php'
            ,{selectLang:selectLang}
            ,function(data)
            {
                $('#selectsection').html(data);
            }
        );

    });
    $('#txtLang').change(function(){
        var txtLang =  $('#txtLang').val();
        if(txtLang != 0)
        {
            $(".langAlarm").hide("slow");
            $("#txtLang").removeClass("border-red");
            $(".lblLang").removeClass("color-red");
        }
        else
        {
            $("#txtLang").addClass("border-red");
            $(".lblLang").addClass("color-red");
            $(".langAlarm").show("slow");
        }
        $(document).ajaxStart(function(){
            $("#loading").css("display", "block");
        });
        $(document).ajaxComplete(function(){
            $("#loading").css("display", "none");
        });
        $.post(
            '../ajax/selectSection.php'
            ,{txtLang:txtLang}
            ,function(data)
            {
                $('#selectSection').html(data);
            }
        );
    });

});