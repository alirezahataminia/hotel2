<?php
class groupedit
{
    public
        $message = ''
    ,$section
    ,$id
    ,$lang
    ,$form
    ,$assets_public_dir = ASSETS_PUBLIC_DIR
    ,$dateupdated
    ,$group
    ,$object
    ;
    public function __construct()
    {
        $id = $_GET['id'];
        if(isset($_POST['fielddelete']))
        {

            $id=($_POST['object'][$_POST['fielddelete']]['id']);
            DatabaseHandler::Execute("DELETE FROM `object` WHERE id=$id");
        }
        if(isset($_POST['fieldedit']))
        {

            $id=($_POST['object'][$_POST['fieldedit']]['id']);
            $title=($_POST['object'][$_POST['fieldedit']]['title']);
            $field=($_POST['object'][$_POST['fieldedit']]['field']);
            DatabaseHandler::Execute("UPDATE `object` SET `feild`='$field',`title`='$title',`group_id`=$_GET[id],`image`='',`order`=''  WHERE id=$id");
        }
        if(isset($_POST['btnFeild']))
        {
            // print_r($_POST);
            foreach ($_POST['object'] as $fild)
            {
                DatabaseHandler::Execute("INSERT INTO `object`(`feild`, `title`, `group_id`, `image`) VALUES ('".$fild['field']."','".$fild['title']."', $_GET[id],'3')");

            }
        }

        $this-> dateupdated =  date::nowTime('Asia/Tehran');
        if (isset($_POST['btnSubmit']))
        {
            $updatetSection = new update();
            $updatetSection -> section_cmstype($_POST['txtId'],$_POST['txtTitle'], $_POST['txtParent'], $_POST['txtBody'], $_POST['txtDescription'], $_POST['txtKeywords'], $_POST['txtPublish'], $_POST['txtModule'], $_POST['txtLang'], ASSETS_PUBLIC_DIR . '/images/group/', $_FILES['txtImage']['name'], $_FILES["txtImage"]["tmp_name"], $_FILES["txtImage"]["size"], 5000000000,$_POST['oldImage'],$_POST['txtDateCreated'],$_POST['txtOrder']);
            $this->message = $updatetSection->getMessage();
        }
        $this -> lang = DatabaseHandler::GetAll("SELECT * FROM lang");
        if(isset($_GET['id']))
        {
            if(CheckValue::check_input($_GET['id']))
            {
                if(CheckValue::check_posetive($_GET['id']))
                {
                    if(section_cmstype::section_cmstype_SelectRow($_GET['id']) != null)
                    {
                        $this->section = section_cmstype::section_cmstype_SelectRow($_GET['id']);
                        $id = $_GET['id'];
                        $this-> group = DatabaseHandler::GetAll("SELECT * FROM section_cmstype WHERE parent=".$id);
                        $this->id = $_GET['id'];
                        $this->object =DatabaseHandler::GetAll("SELECT * FROM object WHERE group_id=".$id);
                    }
                    else
                    {
                        header('Location: ?r=front');
                        exit();
                    }
                }
            }
            else
            {
                header('Location: ?r=front');
                exit();
            }
        }
        else
        {
            header('Location: ?r=front');
            exit();
        }

    }
}