<?php
class sectionmanage
{
    public
    $message = ''
    ,$table
    ,$row_number
    ,$item
    ,$page
    ,$link
    ,$pagination
    ;
    public function __construct()
    {
        if(isset($_POST['deleteItem']))
        {
            $deleteItem = new delete();
            $deleteItem->deleteItmes('section_cmstype',$_POST['deleteId'],ASSETS_PUBLIC_DIR.'/images/section');
            $this->message = $deleteItem -> getMessage();

        }
        if(CheckValue::check_posetive($_GET['page']) == false || CheckValue::check_posetive($_GET['item']) == false)
        {
            header('location: ?r=sectionmanage&page=1&item=10');
        }
        else
        {

            if(isset($_GET['check']))
            {
                $check = $_GET['check'];
                $id = CheckValue::check_input($_GET['id']);
               if (activity::change($check,$id,'section_cmstype')==false)
               {
                   header('Location: ?r=front');
                   exit();
               }
            }
            if(isset($_POST['btnSwap']))
            {
                $swap = new swap();
                $swap -> swapper('section_cmstype',$_POST['swapId'],$_POST['newSwap'],$_POST['oldSwap']);
                $this->message = $swap ->getmessage();
            }
            $query = 'SELECT * FROM section_cmstype WHERE parent=0 ORDER BY `order` DESC';
            $page = CheckValue::check_input($_GET['page']);
            $item = CheckValue::check_input($_GET['item']);
            $this -> table = pagination::paggination($item,$page,$query);
            $this -> pagination = $this -> pagination = pagination::button('sectionmanage',$item,$page,$query);
            $this->page = $page;
            $this->item = $item;
            $this -> link = CheckValue::check_input($_GET['r']);

        }
    }
}