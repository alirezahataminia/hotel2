<?php
class sectionedit
{
    public
        $message = ''
    ,$section
    ,$id
    ,$lang
    ,$form
    ,$assets_public_dir = ASSETS_PUBLIC_DIR
    ,$dateupdated
    ,$group
    ,$table
    ,$page = 1
    ,$item=30
    ;
    public function __construct()
    {
        $this-> dateupdated =  date::nowTime('Asia/Tehran');
        if (isset($_POST['btnSubmit']))
        {
            $updatetSection = new update();
            $updatetSection -> section_cmstype($_POST['txtId'],$_POST['txtTitle'], 0, $_POST['txtBody'], $_POST['txtDescription'], $_POST['txtKeywords'], $_POST['txtPublish'], $_POST['txtModule'], $_POST['txtLang'], ASSETS_PUBLIC_DIR . '/images/section/', $_FILES['txtImage']['name'], $_FILES["txtImage"]["tmp_name"], $_FILES["txtImage"]["size"], 5000000000,$_POST['oldImage'],$_POST['txtDateCreated'],$_POST['txtOrder']);
            $this->message = $updatetSection->getMessage();
        }
        $this -> lang = DatabaseHandler::GetAll("SELECT * FROM lang");
        if(isset($_GET['id']))
        {
            if(CheckValue::check_input($_GET['id']))
            {
                if(CheckValue::check_posetive($_GET['id']))
                {
                    if(section_cmstype::section_cmstype_SelectRow($_GET['id']) != null)
                    {
                        $this->section = section_cmstype::section_cmstype_SelectRow($_GET['id']);
                        $id = $_GET['id'];
                        $this-> group = DatabaseHandler::GetAll("SELECT * FROM section_cmstype WHERE parent=".$id);
                        $this->id = $_GET['id'];
                        $query = "SELECT * FROM section_cmstype WHERE parent=$id ORDER BY `order` DESC";
                        $this -> table = pagination::paggination($this->item,$this->page,$query);
                        $this -> pagination = $this -> pagination = pagination::button('groupmanage',$this->item,$this->page,$query);

                        $this -> link = CheckValue::check_input($_GET['r']);
                    }
                    else
                    {
                        header('Location: ?r=front');
                        exit();
                    }
                }
            }
            else
            {
                header('Location: ?r=front');
                exit();
            }
        }
        else
        {
            header('Location: ?r=front');
            exit();
        }
    }
}