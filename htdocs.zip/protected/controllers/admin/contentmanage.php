<?php
class contentmanage
{
    public
        $message = ''
    ,$table
    ,$row_number
    ,$item
    ,$page
    ,$link
    ,$pagination
    ;
    public function __construct()
    {
        if(isset($_POST['deleteItem']))
        {
            $deleteItem = new delete();
            $this->message=$deleteItem->deleteItmes('content',$_POST['deleteId'],ASSETS_PUBLIC_DIR.'/images/content');

        }
        if(CheckValue::check_posetive($_GET['page']) == false || CheckValue::check_posetive($_GET['item']) == false)
        {
            header('location: ?r=front');
        }
        else
        {

            if(isset($_GET['check']))
            {
                $check = $_GET['check'];
                $id = CheckValue::check_input($_GET['id']);
                if (activity::change($check,$id,'content')==false)
                {
                    header('Location: ?r=front');
                    exit();
                }
            }
            if(isset($_POST['btnSwap']))
            {
                $swap = new swap();
                $swap -> swapper('section_cmstype',$_POST['swapId'],$_POST['newSwap'],$_POST['oldSwap']);
                $this->message = $swap ->getmessage();
            }
            $query = 'SELECT * FROM content  ORDER BY `order` DESC';
            $page = CheckValue::check_input($_GET['page']);
            $item = CheckValue::check_input($_GET['item']);
            $this -> table = pagination::paggination($item,$page,$query);
            $this -> pagination = $this -> pagination = pagination::button('content',$item,$page,$query);
            $this->page = $page;
            $this->item = $item;
            $this -> link = CheckValue::check_input($_GET['r']);

        }
    }
}