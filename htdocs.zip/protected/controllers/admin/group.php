<?php
class group
{
    public
        $message = ''
    ,$thumb_width = THUMB_WIDTH
    ,$thumb_height = THUMB_HEIGHT
    ,$sections
    ,$lang
    ;
    public function __construct()
    {
        $this -> sections = DatabaseHandler::GetAll('SELECT * FROM section_cmstype WHERE parent=0');
        $this -> lang = DatabaseHandler::GetAll("SELECT * FROM lang");
        if (isset($_POST['btnSubmit']))
        {

            $insertSection = new insert();
            $insertSection -> section_cmstype($_POST['txtTitle'], $_POST['txtSection'], $_POST['txtBody'], $_POST['txtDescription'], $_POST['txtKeywords'], $_POST['txtPublish'], $_POST['txtModule'],0,ASSETS_PUBLIC_DIR .'group/', $_FILES['txtImage']['name'],$_FILES["txtImage"]["tmp_name"],$_FILES["txtImage"]["size"],5000000000);
            $this->message = $insertSection -> getMessage();
        }
    }
}