<?php
class article
{
    public
        $message = ''
    ,$thumb_width = THUMB_WIDTH
    ,$thumb_height = THUMB_HEIGHT
    ,$sections
    ,$group
    ;
    public function __construct()
    {
        $this -> sections = DatabaseHandler::GetAll('SELECT * FROM section_cmstype WHERE parent!=0');
        if (isset($_POST['btnSubmit']))
        {

            $insertSection = new insert();
            $insertSection -> content($_POST['txtTitle'], $_POST['txtSection'], $_POST['txtBody'], $_POST['txtDescription'], $_POST['txtKeywords'], $_POST['txtPublish'], $_POST['txtModule'],0,ASSETS_PUBLIC_DIR .'/images/content/', $_FILES['txtImage']['name'],$_FILES["txtImage"]["tmp_name"],$_FILES["txtImage"]["size"],5000000000);
            $this->message = $insertSection -> getMessage();
        }
    }
}