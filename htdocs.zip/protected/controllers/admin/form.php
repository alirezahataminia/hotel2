<?php
class form
{
    public
    $message
    ,$form
    ;
    public function __construct()
    {
        $frm = new formsaz;


//        $option=[
//            ["text"=>'Choose a langueagr ... ',"value"=>'0',"selected"=>''],
//            ["text"=>'22222222',"value"=>'2',"selected"=>'selected'],
//            ["text"=>'3333333',"value"=>'3',"selected"=>'']
//
//        ];
        $option=DatabaseHandler::GetAll("select id as `value` , title as `text` , '' as `selected`  from lang");
        $fields=
            [
            ["index"=>"label1",'type'=>'label','name' => 'labael1','obj_id'=>'1','class'=>'default','for'=>'sdsd'],
            ["index"=>"txtTitle1",'type'=>'text','name' => 'txtTitle1','obj_id'=>'1','class'=>'default',"value"=>'nmnm'],
            ["index"=>"radio",'type'=>'radio','name' => 'txtTitle2','obj_id'=>'2','class'=>'default',"value"=>'nmnm'],
            ["index"=>"radio1",'type'=>'radio','name' => 'txtTitle2','obj_id'=>'2','class'=>'default',"value"=>'nmnm'],
            ["index"=>"radio2",'type'=>'radio','name' => 'txtTitle2','obj_id'=>'2','class'=>'default',"value"=>'nmnm','checked' => 'checked'],
            ["index"=>"radio3",'type'=>'radio','name' => 'txtTitle2','obj_id'=>'2','class'=>'default',"value"=>'nmnm'],
            ["index"=>"checkbox1",'type'=>'checkbox','name' => 'check1','obj_id'=>'10','class'=>'default',"value"=>'nmnm'],
            ["index"=>"checkbox2",'type'=>'checkbox','name' => 'check1','obj_id'=>'10','class'=>'default',"value"=>'nmnm','checked' => 'checked'],
            ["index"=>"checkbox3",'type'=>'checkbox','name' => 'check1','obj_id'=>'10','class'=>'default',"value"=>'nmnm','checked' => 'checked'],
            ["index"=>"checkbox4",'type'=>'checkbox','name' => 'check1','obj_id'=>'10','class'=>'default',"value"=>'nmnm'],
            ["index"=>"select",'type'=>'select','name' => 'check1','obj_id'=>'10','class'=>'default',"value"=>"sjk","option"=>$option,"multiple"=>""]
        ];
        $frm ->generate('nm.php','post','25',$fields);
        $this -> form = $frm ->render();
    }
}