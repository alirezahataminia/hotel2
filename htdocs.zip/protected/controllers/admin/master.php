<?php
  class master
  {
      public
      $page = 'front.tpl'
      ,$fullname
      ,$assets_admin_dir = ASSETS_ADMIN_DIR
      ,$assets_public_dir = ASSETS_PUBLIC_DIR

      ;
      function __construct()
      {
//          if(authentication::isUserLoggedIn())
//          {
//              if(!roleprovider::checkUserPermission(14))
//              {
//                  die('access denied')  ;
//              }
//          }
//          else
//          {
//              header('location: ../index.php?r=front');
//          }

          if(isset($_GET['id']))
          {

              if(!CheckValue::check_int($_GET['id']) || $_GET['id'] < 1)
              {
                  header('Location: ?r=dashboard');
              }
          }
          if(isset($_GET['r']))
          {
              $r = CheckValue::check_input($_GET['r']);
              $this->active = $r;
              $this->page = $r . '.tpl';
          }
      }
  }
?>