<?php
class contentedit
{
    public
        $message = ''
    ,$section
    ,$id
    ,$lang
    ,$form
    ,$assets_public_dir = ASSETS_PUBLIC_DIR
    ,$dateupdated
    ,$group
    ,$object
    ,$group2
    ,$values
    ;
    public function __construct()
    {
        $id = $_GET['id'];
        if(isset($_POST['btnFeild']))
        {
            $i=0;
            foreach ($_POST['values'] as $value )
            {
                DatabaseHandler::Execute("INSERT INTO `values`(`value`, `articles_id`, `object_id`) VALUES ('$value',$id,".$_POST['object_id'][$i].")");
                $i++;
            }
        }
        $this-> dateupdated =  date::nowTime('Asia/Tehran');
        if (isset($_POST['btnSubmit']))
        {
            $updatetSection = new update();
            $updatetSection -> content($_POST['txtId'],$_POST['txtTitle'], $_POST['txtParent'], $_POST['txtBody'], $_POST['txtDescription'], $_POST['txtKeywords'], $_POST['txtPublish'], $_POST['txtModule'],  ASSETS_PUBLIC_DIR . '/images/content/', $_FILES['txtImage']['name'], $_FILES["txtImage"]["tmp_name"], $_FILES["txtImage"]["size"], 5000000000,$_POST['oldImage'],$_POST['txtDateCreated']);
            $this->message = $updatetSection->getMessage();
        }
        $this -> lang = DatabaseHandler::GetAll("SELECT * FROM lang");
        if(isset($_GET['id']))
        {
            if(CheckValue::check_input($_GET['id']))
            {
                if(CheckValue::check_posetive($_GET['id']))
                {
                    if(content::content_SelectRow($_GET['id']) != null)
                    {
                        $this->section = content::content_SelectRow($_GET['id']);
                        $id = $_GET['id'];
                        $this-> group = DatabaseHandler::GetAll("SELECT * FROM section_cmstype WHERE parent=".$id);
                        $this->id = $_GET['id'];
                        $this -> object = DatabaseHandler::GetAll("SELECT * FROM object WHERE group_id=".$this->section['parent']);
                        $this->values=DatabaseHandler::GetAll("select * from `values` where articles_id=$_GET[id]");
                        $this-> group2 = DatabaseHandler::GetAll("SELECT * FROM section_cmstype WHERE parent!=0");

                    }
                    else
                    {
                        header('Location: ?r=front');
                        exit();
                    }
                }
            }
            else
            {
                header('Location: ?r=front');
                exit();
            }
        }
        else
        {
            header('Location: ?r=front');
            exit();
        }

    }
}