<?php

class sectionUpdate
{
    public
        $message = ''
    , $thumb_width = THUMB_WIDTH
    , $thumb_height = THUMB_HEIGHT
    , $lang
    , $form;

    public function __construct()
    {
        $section = DatabaseHandler::GetRow("SELECT * FROM section_cmstype WHERE id=61");
        //$this->lang = DatabaseHandler::GetAll('SELECT * FROM lang');
        $optionLang = DatabaseHandler::GetAll("select id as `value` , title as `text` , '' as `selected`  from lang");
        for($i=0;$i<=count($optionLang)-1;$i++)
        {
            echo $optionLang[$i]['value'].'=='.$section['lang'];
            if($optionLang[$i]['value']==$section['lang'])
            {
                echo'test';
                $optionLang[$i]['selected']="selected";
            }
        }
        $enable = null;
        $disable = null;
        if($section['activity'] == 1)
        {
            $enable = 'checked';
        }
        else
        {
            $disable = 'checked';
        }
       // array_unshift($optionLang, ["text" => 'Choose a langueage ... ', "value" => '0', "selected" => '']);
        $frm = new formsaz;
        $fields =
            [
                ["index" => "lblTitle", 'type' => 'label', 'name' => 'Title :', 'obj_id' => '', 'class' => 'lblTitle', 'for' => 'txtTitle'],
                ["index" => "txtTitle", 'type' => 'text', 'name' => 'txtTitle', 'obj_id' => 'txtTitle', 'class' => 'form-control txtTitle', "value" => $section['title'], "autocomplete" => "on"],

                ["index" => "lblModule", 'type' => 'label', 'name' => 'Module :', 'obj_id' => '', 'class' => '', 'for' => 'txtModule'],
                ["index" => "txtModule", 'type' => 'text', 'name' => 'txtModule', 'obj_id' => 'txtModule', 'class' => 'form-control', "value" => $section['madule'], "autocomplete" => "off"],

                ["index" => "lblLang", 'type' => 'label', 'name' => 'Language :', 'obj_id' => '', 'class' => '', 'for' => 'txtLang'],
                ["index" => "txtLang", 'type' => 'select', 'name' => 'txtLang', 'obj_id' => 'txtLang', 'class' => 'form-control', "value" => "sjk", "option" => $optionLang, "multiple" => ""],

                ["index" => "lblImg", 'type' => 'label', 'name' => 'Images input :', 'obj_id' => '', 'class' => '', 'for' => 'txtImage'],
                ["index" => "txtImage", 'type' => 'file', 'name' => 'txtImage', 'obj_id' => 'txtImage', 'class' => '', "value" => '', "autocomplete" => "off"],

                ["index" => "lblPublish", 'type' => 'label', 'name' => 'publish status :', 'obj_id' => '', 'class' => '', 'for' => ''],
                ["index" => "lblPublishEnabel", 'type' => 'label', 'name' => 'Enabel', 'obj_id' => '', 'class' => '', 'for' => 'txtPublish1'],
                ["index" => "lblPublishDisabel", 'type' => 'label', 'name' => 'Disabel', 'obj_id' => '', 'class' => '', 'for' => 'txtPublish2'],
                ["index" => "txtPublish1", 'type' => 'radio', 'name' => 'txtPublish', 'obj_id' => 'txtPublish', 'class' => 'default', "value" => '0','checked' => $disable],
                ["index" => "txtPublish2", 'type' => 'radio', 'name' => 'txtPublish', 'obj_id' => 'txtPublish', 'class' => 'default', "value" => '1', 'checked' => $enable],

                ["index" => "lblBody", 'type' => 'label', 'name' => 'Body :', 'obj_id' => '', 'class' => 'lblTitle', 'for' => 'txtBody'],
                ["index" => "txtBody", 'type' => 'textarea', 'name' => 'txtBody', 'obj_id' => 'body','rows'=>'200','cols'=>'', 'class' => 'form-control', "value" => $section['body']],

                ["index" => "lblDescription", 'type' => 'label', 'name' => 'Description :', 'obj_id' => '', 'class' => 'lblTitle', 'for' => 'txtDescription'],
                ["index" => "txtDescription", 'type' => 'textarea', 'name' => 'txtDescription', 'obj_id' => 'txtDescription','rows'=>'7','cols'=>'', 'class' => 'form-control', "value" => $section['description']],


                ["index" => "lblKeywords", 'type' => 'label', 'name' => 'Keywords :', 'obj_id' => '', 'class' => 'lblTitle', 'for' => 'txtKeywords'],
                ["index" => "txtKeywords", 'type' => 'textarea', 'name' => 'txtKeywords', 'obj_id' => 'txtKeywords','rows'=>'7','cols'=>'', 'class' => 'form-control', "value" => $section['keywords']],

            ];
        $frm->generate('', 'post', 'sectionCmstypeForm','frm',' enctype="multipart/form-data"', $fields);
        $this->form = $frm->render();


        if (isset($_POST['btnSubmit'])) {
            $insertSection = new insert();
            $insertSection->section_cmstype($_POST['txtTitle'], 0, $_POST['txtBody'], $_POST['txtDescription'], $_POST['txtKeywords'], $_POST['txtPublish'], $_POST['txtModule'], $_POST['txtLang'], '../assets/public/section/', $_FILES['txtImage']['name'], $_FILES["txtImage"]["tmp_name"], $_FILES["txtImage"]["size"], 5000000000);
            $this->message = $insertSection->getMessage();
        }

    }
}