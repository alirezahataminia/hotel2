<?php

class room
{
    public
        $Page = "main.tpl"
    , $assets_front_dir = ASSETS_FRONT_DIR
    , $assets_public_dir = ASSETS_PUBLIC_DIR
    , $room
    ,$object
;
    function __construct()
    {
        $parent = DatabaseHandler::GetRow("SELECT * FROM section_cmstype WHERE module='mod_room_fa' && activity=1");
        $query = "SELECT * from content where parent= $parent[id]";
        $this->room = DatabaseHandler::GetAll($query); 
        $query = "SELECT object.*, `values`.value ,`values`.articles_id from object join `values` on object.id = `values`.object_id";
        $this->object = DatabaseHandler::GetAll($query);
    }
}


