<?php 
    class page
    {
        public
        $Page="main.tpl"
        ,$assets_front_dir = ASSETS_FRONT_DIR
        ,$assets_public_dir = ASSETS_PUBLIC_DIR
        ,$assets_img=PUBLIC_IMG_DIR.'/content'
        ,$content
        ;
        function __construct()
        {
           // $parent=DatabaseHandler::GetRow("SELECT * FROM section_cmstype WHERE module='mod_contact_us' && activity=1");
            //$this->contact=DatabaseHandler::GetRow("SELECT * FROM content WHERE parent=$parent[id] && activity=1");
            $module=$_GET['module'];
            $id = DatabaseHandler::GetOne("SELECT content.id FROM content JOIN section_cmstype ON section_cmstype.id = content.parent WHERE section_cmstype.module='$module'");
            $this->content=DatabaseHandler::GetRow("select * from content where id=$id");

        }
    }


