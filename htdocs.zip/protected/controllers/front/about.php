<?php 
    class about
    {
        public
        $Page="main.tpl"
        ,$assets_front_dir = ASSETS_FRONT_DIR
        ,$assets_public_dir = ASSETS_PUBLIC_DIR
        ,$about
        ;
        function __construct()
        {
            $parent=DatabaseHandler::GetRow("SELECT * FROM section_cmstype WHERE module='mod_about_us' && activity=1");
            $this->about=DatabaseHandler::GetAll("SELECT * FROM content WHERE parent=$parent[id] && activity=1");
        }
    }


