<?php 
    class front
    {
        public
        
        function __construct()
        {
            
        }
    }


