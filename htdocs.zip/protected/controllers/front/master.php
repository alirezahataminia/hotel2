<?php 
    class master
    {
        public
            $page = 'front.tpl'
        ,$assets_front_dir = ASSETS_FRONT_DIR
        ,$assets_public_dir = ASSETS_PUBLIC_DIR
        ;
        function __construct()
        {
            if(isset($_GET['r']))
            {
                $r = CheckValue::check_input($_GET['r']);
                $this->page = $r . '.tpl';
            }
        }
    }


