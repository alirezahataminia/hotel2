<?php
class counter{
    public static function newsCounter($id)
    {
        $check = seen::seen_selectAllByArticleId($id);
        if(!empty($check))
        {
            $flag = $check['seen'];
            $flag++;
            seen::seen_updateByArticlid($id,$flag);
        }
        else
        {
            seen::seen_Insert(1,$id);
        }
    }
}