<?php
class pagination
{
    public static function paggination($items,$page,$query)
    {
        $start = ($page - 1) * $items;

        $result = $query . ' LIMIT '  . $start . ',' . $items;

        return DatabaseHandler::GetAll($result);
    }
    public static function button($main_page,$items,$page,$query)
    {
        $next = $page + 1;
        $previous = $page - 1;
       $count = DatabaseHandler::GetAll($query);
        $num = 0;
        foreach ($count as $count1)
        {
            $num++;
        }
        $active = $page;
        $page = ceil($num/$items);
        if($next<$page+1)
        {
            $next = '<li><a href="?r='.$main_page.'&page='.$next.'&item='.$items.'" aria-label="Next"><span aria-hidden="true">»</span></a></li>';
        }
        else
        {
            $next = '<li class="disabled"><a href="#" aria-label="Next"><span aria-hidden="true">»</span></a></li>';
        }
        if($previous>0)
        {
            $previous = '<li><a href="?r='.$main_page.'&page='.$previous.'&item='.$items.'" aria-label="Next"><span aria-hidden="true">«</span></a></li>';
        }
        else
        {
            $previous = '<li class="disabled"><a href="#" aria-label="Next"><span aria-hidden="true">«</span></a></li>';
        }
        $button = '';
        for($i=1; $i<=$page;$i++)
        {
            if ($i == $active)
            {
                $button .= '<li class="active"><a href="?r='.$main_page.'&page='.$i.'&item='.$items.'">' .$i. '</a></li>';
            }
            else
            {
                $button .= '<li><a href="?r='.$main_page.'&page='.$i.'&item='.$items.'">' .$i. '</a></li>';
            }
        }
        $button = '<div class="col-lg-12 text-center">
                        <ul class="pagination">
                        '.$previous.$button.$next.'
                        </ul>
                </div>';
        return $button;
    }

}