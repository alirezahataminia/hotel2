<?php
class thumbnail
{
    public static function thumb($add,$n_width,$tsrc)
    {
        $info = getimagesize($add);

        if($info['mime'] == 'image/jpeg')
        {
            $im=ImageCreateFromJPEG($add);
            $width=ImageSx($im);
            $height=ImageSy($im);
            $n_height=($n_width/$width) * $height;
            $newimage=imagecreatetruecolor($n_width,$n_height);
            imageCopyResized($newimage,$im,0,0,0,0,$n_width,$n_height,$width,$height);
            ImageJpeg($newimage,$tsrc);
            chmod("$tsrc",0777);
        }
        if($info['mime'] == 'image/gif')
        {
            $im=ImageCreateFromGIF($add);
            $width=ImageSx($im);
            $height=ImageSy($im);
            $n_height=($n_width/$width) * $height;
            $newimage=imagecreatetruecolor($n_width,$n_height);
            imageCopyResized($newimage,$im,0,0,0,0,$n_width,$n_height,$width,$height);
            ImageJpeg($newimage,$tsrc);
            chmod("$tsrc",0777);
        }
        if($info['mime'] == 'image/png')
        {
            $im=ImageCreateFromPNG($add);
            $width=ImageSx($im);
            $height=ImageSy($im);
            $n_height=($n_width/$width) * $height;
            $newimage=imagecreatetruecolor($n_width,$n_height);
            imageCopyResized($newimage,$im,0,0,0,0,$n_width,$n_height,$width,$height);
            ImageJpeg($newimage,$tsrc);
            chmod("$tsrc",0777);
        }

    }
}