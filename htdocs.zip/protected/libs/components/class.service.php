<?php
require_once '../libs/nusoap/nusoap.php';
require_once '../include/config.php';

$server = new nusoap_server();
$server->configureWSDL("myservice","urn:service1");

//method check login
function checkLogin($email,$password)
{

    $email = CheckValue::check_input($email);
    $password = CheckValue::check_input($password);
    $param  = authentication::login($email,$password) ;

        return '{"checkLogin":' . json_encode($param) . '}';
}
//method show comments
function showComments($id)
{

   $param = DatabaseHandler::GetAll("SELECT comments.id , comments.article_id , comments.body , comments.date ,users.fullname FROM comments JOIN articles ON articles.id=comments.article_id JOIN users ON users.id=comments.user_id WHERE comments.activity=1 AND articles.id=$id");

        return '{"showComments":' . json_encode($param) . '}';
}
//method selct all categories
function cmsType()
{

   $param = DatabaseHandler::GetAll("SELECT cmstype.title , cmstype.id FROM cmstype JOIN section_cmstype ON cmstype.id=section_cmstype.cmstype_id WHERE cmstype.activity=1 AND section_cmstype.section_id=11");

        return '{"cmsType":' . json_encode($param) . '}';
}

//method select articles by cmstype_id
function articlesByCmsTypeId($id)
{

   $param = DatabaseHandler::GetAll("SELECT articles.title , articles.id , articles.lead , articles.date ,articles.author , articles.pics FROM articles JOIN cmstype ON cmstype.id=articles.cmstype_id WHERE articles.activity=1 AND articles.cmstype_id=$id ORDER BY id DESC");

        return '{"articlesByCmsTypeId":' . json_encode($param) . '}';
}
//method select article by id
function articlesById($id)
{

   $param = DatabaseHandler::GetAll("SELECT id, ontitle, title, lead, author, translator, date, cmstype_id, pics, description, counter, keywords, price FROM articles WHERE id=$id AND activity=1");

        return '{"articlesById":' . json_encode($param) . '}';
}
//method select all articles
function articlesAll()
{

   $param = DatabaseHandler::GetAll("SELECT id, ontitle, title, lead, author, translator, date, cmstype_id, pics, description, counter, keywords, price FROM articles WHERE activity=1");

       return '{"articlesAll":' . json_encode($param) . '}';


}
// All Articles Register
$server->register(
    "articlesAll"
    ,array()
    ,array("title"=>"xsd:string")
);
// Check Login By email and Password
$server->register(
    "checkLogin"
    ,array("email"=>"xsd:string","password"=>"xsd:string")
    ,array("check"=>"xsd:string")
);
// Show Comments By Article Id
$server->register(
    "showComments"
    ,array("id"=>"xsd:int")
    ,array("comments"=>"xsd:string")
);
// Article By Id Register
$server->register(
    "articlesById"
    ,array("id"=>"xsd:int")
    ,array("article"=>"xsd:string")
);
// Articles By CmsType Id
$server->register(
    "articlesByCmsTypeId"
    ,array("id"=>"xsd:int")
    ,array("article"=>"xsd:string")
);
// Select Section Register
$server->register(
    "cmsType"
    ,array()
    ,array("section"=>"xsd:string")
);
$HTTP_RAW_POST_DATA = isset($HTTP_RAW_POST_DATA) ? $HTTP_RAW_POST_DATA : '';
$server->service($HTTP_RAW_POST_DATA);