<?php
class delete
{
    private
        $message
    ;
    public function deleteItmes($table,$id,$path)
    {
            $query = DatabaseHandler::GetRow("SELECT * FROM $table WHERE id=$id");
        if($query == false)
        {
            $this->message = messages::showMessageFailure("oops! the table is required Not found");
                $alert = new delete();
                $alert -> getMessage();
            return false;
        }
        else
        {
            DatabaseHandler::Execute("DELETE FROM $table WHERE id=$id");
            if($query['image'] != 'default.jpg')
            {
                unlink($path . "/$query[image]");
                unlink($path . "/thumb/$query[image]");
            }
            $this->message = messages::ShowMessageSuccess("The table is deleted successfully");
                $alert = new delete();
                $alert -> getMessage();
            return true;
        }
    }
    public function getMessage()
    {
        return $this -> message;
    }
}