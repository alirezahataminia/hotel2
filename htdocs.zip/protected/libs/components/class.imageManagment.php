<?php
class imageManagment
{
    public static function imagepermission($filename,$type)
    {
        
//      $char='abcdefghijklmnopqrstuxyvwzABCDEFGHIJKLMNOPQRSTUXYVWZ123456789';
//      $charnumber =strlen($char);
//      $randomnumber ="";
//      for($i=0;$i<70;$i++)
//      {
//        $index = mt_rand(0,$charnumber-1);
//        $randomnumber .= $char[$index];
//
//       }
      switch($type)
           {
              case 'image/gif' : $type = '.gif';
              break;
              case 'image/jpeg' : $type = '.jpeg';
              break;
              case 'image/jpg' : $type = '.jpg';
              break;
              case 'image/png' : $type = '.png';
              break;
              default :
              $type = 'no';
          }
      if($type=='no')
      {
          return false;
      }
      else
      {
//          return $randomnumber . $type;
          $plus = 1;
          while(file_exists('../assets/public/section/' . $filename.$type) == true)
          {
              $filename = $filename . ' ('.$plus.')';
              $plus++;
          }
          return $filename;
      }
    }
    public static function imageDelete($imageId,$imageAddress)
    {
        $rout = articles::articles_SelectRow($imageId);
        if($rout['pics']!='default.jpg')
        {
             $address =  $imageAddress . $rout['pics'];
             unlink( $address );
        }
        return false;
    }
    public static function imageDeleteFromGallery($address)
    {
        unlink( $address ); 
    }
    public static function uploadImage($tmp,$name)
    {
        move_uploaded_file($tmp,$name);
    }
    public static function showGallery($address)
    {
        $directoryHandle = opendir($address);
        $d = array();
        while($filename = readdir($directoryHandle))
        {
            if($filename != '.' && $filename != '..')
            {
                 $d[] = $filename;
            }
        }
        return $d;         
    }
}