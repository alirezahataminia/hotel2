<?php
class insert
{

    private
        $message = ''
    ;
    public function section_cmstype($title,$parent,$body,$description,$keywords,$activity,$module,$lang,$imagePath,$imageName,$imageTmpName,$imageSize,$size)
    {
        $title = CheckValue::check_input($title);
        $parent = CheckValue::check_input($parent);
        $lang = CheckValue::check_input($lang);
        $date_created = date::nowTime('Asia/Tehran');
        $body = CheckValue::check_input($body);
        $description = CheckValue::check_input($description);
        $keywords = CheckValue::check_input($keywords);
        $activity = CheckValue::check_input($activity);
        $module = CheckValue::check_input($module);
        $flag = 1;
        if(empty($imageName))
        {
            $image = 'default.jpg';
        }
        else
        {
            $upload = new uploader;
            $image = $upload -> uploadFile($imagePath, $imageName,$imageTmpName,$imageSize,$size);
            $alert = $upload ->getMessage();
            if($image == false)
            {
                $this -> message = messages::showMessageFailure($alert);
                $flag = 0;
            }
            else
            {
                $this -> message = messages::ShowMessageSuccess($alert);
            }
        }
        if($flag == 1)
        {
            section_cmstype::section_cmstype_Insert($title,$lang,$parent,$image,$date_created,$date_created,$body,$description,$keywords,$activity,1,$module);
            $s = DatabaseHandler::GetOne("select LAST_INSERT_ID();");
            DatabaseHandler::Execute("UPDATE `section_cmstype` SET `order`=$s WHERE id=$s");
            $this -> message =  messages::ShowMessageSuccess(MSG_EN_INSERT_SECTION_SUCCESS);
        }
        
    }
    public function content($title,$parent,$body,$description,$keywords,$activity,$module,$lang,$imagePath,$imageName,$imageTmpName,$imageSize,$size)
    {
        $title = CheckValue::check_input($title);
        $parent = CheckValue::check_input($parent);
        $lang = CheckValue::check_input($lang);
        $date_created = date::nowTime('Asia/Tehran');
        $body = CheckValue::check_input($body);
        $description = CheckValue::check_input($description);
        $keywords = CheckValue::check_input($keywords);
        $activity = CheckValue::check_input($activity);
        $module = CheckValue::check_input($module);
        $flag = 1;
        if(empty($imageName))
        {
            $image = 'default.jpg';
        }
        else
        {
            $upload = new uploader;
            $image = $upload -> uploadFile($imagePath, $imageName,$imageTmpName,$imageSize,$size);
            $alert = $upload ->getMessage();
            if($image == false)
            {
                $this -> message = messages::showMessageFailure($alert);
                $flag = 0;
            }
            else
            {
                $this -> message = messages::ShowMessageSuccess($alert);
            }
        }
        if($flag == 1)
        {
            content::content_Insert($title,$parent,$image,$date_created,$date_created,$body,$description,$keywords,$activity,1,$module,$lang);
            $s = DatabaseHandler::GetOne("select LAST_INSERT_ID();");
            DatabaseHandler::Execute("UPDATE `content` SET `order`=$s WHERE id=$s");
            $this -> message =  messages::ShowMessageSuccess(MSG_EN_INSERT_SECTION_SUCCESS);
        }

    }

    public function getMessage()
    {
        return $this -> message;
    }
}