<?php
class register
{
    static function checkEMailExist($email)
    {
        $emailCheck = DatabaseHandler::GetRow("SELECT * FROM users WHERE email=$email");
        if($emailCheck['activity'] == 0)
        {
            return 'error';
        }
    }
}