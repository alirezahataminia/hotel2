<?php
class jsonHandler
{
    public static function dashboard()
    {
        $objects = array(
          'section' => 'بخش ها'
        , 'groups' => 'گروه ها'
        , 'content' => 'افزودن مطالب'
        , 'contentManage' => 'مدیریت مطالب'
        , 'sectionIcon' => 'glyphicon glyphicon-hdd'
        , 'groupsIcon' => 'glyphicon glyphicon-folder-open'
        , 'contentIcon' => 'glyphicon glyphicon-plus'
        , 'contentManageIcon' => 'glyphicon glyphicon-duplicate'
        , 'sectionDescription' => 'در لینک بخش ها شما می توانید ب خش جدید تعریف کرده و یا بخش های ثبت شده را مدیریت کنید '
        , 'groupsDescription' => 'در صفحه گروه ها شما می توانید گروه جدید ثبت کنید و یا گروه های از پیش ثبت شده را مدیریت کنید'
        , 'contentDescription' => 'در صفحه افزودن مطالب شما می توانید مطلب جدید را درج کرده و بخش و گروه مربوط به آن را تعیین کنید'
        , 'contentManageDescription' => 'در صفحه مدیریت مطالب شما می توانید مطلب از پیش تعیین شده را مدیریت و ویرایش کنید'
        );
        $objects = json_encode($objects);
        $dashboard = json_decode($objects,true);
        return($dashboard);
    }
    public static function section()
    {
        $objects = array(
            'title' => 'بخش جدید :'
        ,   'section' => 'بخش ها'
        ,   'sectionIcon' => 'glyphicon glyphicon-hdd'
        ,   'image' => 'انتخاب تصویر :'
        ,   'activity' => 'وضعیت انتشار :'
        ,   'enable' => 'فعال :'
        ,   'disable' => 'غیرفعال :'
        ,   'description' => 'توضیحات :'
        ,   'imageAlert' => 'در صورت عدم انتخاب ، تصویر پیشفرض انتخاب می شود'
        ,   'titleAlert' => 'فیلد عنوان نباید خالی باشد'
        ,   'tableHead' => 'کلیه بخش های موجود'
        );
        $objects = json_encode($objects);
        $dashboard = json_decode($objects,true);
        return($dashboard);
    }
    public static function sectionUpdate()
    {
        $objects = array(
            'title' => 'نام بخش :'
        ,   'sectionUpdate' => 'ویرایش بخش'
        ,   'sectionUpdateDes' => 'در اینجا شما می توانید بخش های موجود را ویرایش کنید'
        ,   'sectionUpdateIcon' => 'glyphicon glyphicon-hdd'
        ,   'image' => 'انتخاب تصویر :'
        ,   'activity' => 'وضعیت انتشار :'
        ,   'enable' => 'فعال :'
        ,   'disable' => 'غیرفعال :'
        ,   'description' => 'توضیحات :'
        ,   'imageAlert' => 'در صورت عدم انتخاب،تصویر تغییر نمی کند'
        ,   'titleAlert' => 'فیلد عنوان نباید خالی باشد'
        ,   'noCmstype' => 'هیچ گروهی در این بخش وجود ندارد'
        ,   'tableHead' => 'گروه های موجود در این بخش'
        ,   'th1' => 'ردیف'
        ,   'th2' => 'گروه ها'
        ,   'th3' => 'ویرایش'
        );
        $objects = json_encode($objects);
        $dashboard = json_decode($objects,true);
        return($dashboard);
    }
    public static function cmstype()
    {
        $objects = array(
            'title' => 'گروه جدید :'
        ,   'cmstype' => 'گروه ها'
        ,   'cmstypeIcon' => 'glyphicon glyphicon-folder-open'
        ,   'image' => 'انتخاب تصویر :'
        ,   'activity' => 'وضعیت انتشار :'
        ,   'enable' => 'فعال :'
        ,   'disable' => 'غیرفعال :'
        ,   'description' => 'توضیحات :'
        ,   'imageAlert' => 'در صورت عدم انتخاب ، تصویر پیشفرض انتخاب می شود'
        ,   'titleAlert' => 'فیلد عنوان نباید خالی باشد'
        ,   'tableHead' => 'کلیه گروه های موجود'
        ,   'sectionOptionDefault' => 'بخش مربوطه را انتخاب کنید'
        ,   'selectSectionAlarm' => 'بخش مربوط به این گروه را انتخاب کنید'
        );
        $objects = json_encode($objects);
        $dashboard = json_decode($objects,true);
        return($dashboard);
    }
    public static function cmstypeUpdate()
    {
        $objects = array(
            'title' => 'نام گروه :'
        ,   'cmstype' => 'گروه ها'
        ,   'cmstypeIcon' => 'glyphicon glyphicon-folder-open'
        ,   'image' => 'انتخاب تصویر :'
        ,   'activity' => 'وضعیت انتشار :'
        ,   'enable' => 'فعال :'
        ,   'disable' => 'غیرفعال :'
        ,   'description' => 'توضیحات :'
        ,   'imageAlert' => 'در صورت عدم انتخاب، تصویری جایگزین نمی شود'
        ,   'titleAlert' => 'فیلد عنوان نباید خالی باشد'
        ,   'tableHead' => 'کلیه مطالب مرتبط با این گروه'
        ,   'sectionOptionDefault' => 'بخش مربوطه را انتخاب کنید'
        ,   'selectSectionAlarm' => 'بخش مربوط به این گروه را انتخاب کنید'
        ,   'cmstypeExtraFieldTitle' => 'ویرایش فیلدهای ویژه'
        );
        $objects = json_encode($objects);
        $dashboard = json_decode($objects,true);
        return($dashboard);
    }
    public static function content()
    {
        $objects = array(
            'title' => 'عنوان مطلب:'
        ,   'cmstype' => 'انتخاب گروه:'
        ,   'content' => 'افزودن مطلب جدید'
        ,   'section' => 'انتخاب بخش :'
        ,   'contentIcon' => 'glyphicon glyphicon-duplicate'
        ,   'image' => 'انتخاب تصویر :'
        ,   'activity' => 'وضعیت انتشار :'
        ,   'enable' => 'فعال :'
        ,   'disable' => 'غیرفعال :'
        ,   'description' => 'توضیحات :'
        ,   'body' => 'متن :'
        ,   'price' => 'قیمت :'
        ,   'date' => 'تاریخ انتشار:'
        ,   'author' => 'نویسنده:'
        ,   'translator' => 'مترجم:'
        ,   'ontitle' => 'رو تیتر:'
        ,   'source' => 'منبع:'
        ,   'lead' => 'عنوان کوتاه:'
        ,   'description' => 'توضیحات:'
        ,   'keywords' => 'کلمات کلیدی:'
        ,   'imageAlert' => 'در صورت عدم انتخاب ، تصویر پیشفرض انتخاب می شود'
        ,   'titleAlert' => 'فیلد عنوان مطلب نباید خالی باشد'
        ,   'tableHead' => 'کلیه بخش های موجود'
        ,   'sectionOptionDefault' => 'بخش مربوطه را انتخاب کنید'
        ,   'selectSectionAlarm' => 'بخش مربوط به این گروه را انتخاب کنید'
        ,   'selectSCmstypeAlarm' => 'نام گروه مربوطه را انتخاب کنید'
        );
        $objects = json_encode($objects);
        $dashboard = json_decode($objects,true);
        return($dashboard);
    }
    public static function contentManage()
    {
        $objects = array(
            'contentManageTitle' => 'مدیریت مطالب'
        ,   'cmstype' => 'انتخاب گروه:'
        ,   'content' => 'افزودن مطلب جدید'
        ,   'section' => 'انتخاب بخش :'
        ,   'contentManageIcon' => 'glyphicon glyphicon-duplicate'
        ,   'image' => 'انتخاب تصویر :'
        ,   'activity' => 'وضعیت انتشار :'
        ,   'enable' => 'فعال :'
        ,   'disable' => 'غیرفعال :'
        ,   'description' => 'توضیحات :'
        ,   'imageAlert' => 'در صورت عدم انتخاب ، تصویر پیشفرض انتخاب می شود'
        ,   'titleAlert' => 'فیلد عنوان مطلب نباید خالی باشد'
        ,   'tableHead' => 'کلیه بخش های موجود'
        ,   'sectionOptionDefault' => 'بخش مربوطه را انتخاب کنید'
        ,   'selectSectionAlarm' => 'بخش مربوط به این گروه را انتخاب کنید'
        ,   'selectSCmstypeAlarm' => 'نام گروه مربوطه را انتخاب کنید'
        );
        $objects = json_encode($objects);
        $dashboard = json_decode($objects,true);
        return($dashboard);
    }
    public static function contentUpdate()
    {
        $objects = array(
            'title' => 'عنوان مطلب:'
        ,   'cmstype' => 'انتخاب گروه:'
        ,   'content' => 'افزودن مطلب جدید'
        ,   'section' => 'انتخاب بخش :'
        ,   'contentIcon' => 'glyphicon glyphicon-duplicate'
        ,   'image' => 'انتخاب تصویر :'
        ,   'activity' => 'وضعیت انتشار :'
        ,   'enable' => 'فعال :'
        ,   'disable' => 'غیرفعال :'
        ,   'description' => 'توضیحات :'
        ,   'imageAlert' => 'در صورت عدم انتخاب ، تصویر پیشفرض انتخاب می شود'
        ,   'titleAlert' => 'فیلد عنوان مطلب نباید خالی باشد'
        ,   'tableHead' => 'کلیه بخش های موجود'
        ,   'sectionOptionDefault' => 'بخش مربوطه را انتخاب کنید'
        ,   'selectSectionAlarm' => 'بخش مربوط به این گروه را انتخاب کنید'
        ,   'selectSCmstypeAlarm' => 'نام گروه مربوطه را انتخاب کنید'
        );
        $objects = json_encode($objects);
        $dashboard = json_decode($objects,true);
        return($dashboard);
    }
}