<?php
class swap
{
    private
        $message
;
    public function swapper($table,$swapId,$newSwap,$oldSwap)
    {
        $check1 = 'SELECT * FROM '.$table.' WHERE `order`= '.$oldSwap.'';
        $check1 = DatabaseHandler::GetAll($check1);
        $check2 = 'SELECT * FROM '.$table.' WHERE `order`= '.$newSwap.'';
        $check2 = DatabaseHandler::GetAll($check2);

        if($newSwap == '' || $newSwap == 0)
        {
            $this -> message = messages::showMessageFailure('Oops! that should not be empty!');
            return false;
        }
        elseif($check1==null || $check2==null)
        {
            $this -> message = messages::showMessageFailure('Oops! the record did not find!');
            return false;
        }
        elseif($newSwap == $oldSwap)
        {
            $this -> message = messages::showMessageFailure('Oops! That is same value');
            return false;
        }
        else
        {
            $query2 = 'UPDATE '.$table.' SET `order`='.$oldSwap.' WHERE `order`='.$newSwap.'';
            $query1 = 'UPDATE '.$table.' SET `order`='.$newSwap.' WHERE id='.$swapId.'';
            DatabaseHandler::Execute($query2);
            DatabaseHandler::Execute($query1);
            $this ->message = messages::ShowMessageSuccess('Good Job! swapping was complete');
            return true;
        }
    }
    public function getmessage()
    {
        return $this->message;
    }
}