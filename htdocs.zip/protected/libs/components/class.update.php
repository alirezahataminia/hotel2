<?php
class update
{

    private
        $message = ''
    ;
    public function section_cmstype($id,$title,$parent,$body,$description,$keywords,$activity,$module,$lang,$imagePath,$imageName,$imageTmpName,$imageSize,$size,$oldImage,$date,$order)
    {
        $title = CheckValue::check_input($title);
        $parent = CheckValue::check_input($parent);
        $lang = CheckValue::check_input($lang);
        $date_created = $date;
        $date_updated = date::nowTime('Asia/Tehran');
        $body = CheckValue::check_input($body);
        $description = CheckValue::check_input($description);
        $keywords = CheckValue::check_input($keywords);
        $activity = CheckValue::check_input($activity);
        $module = CheckValue::check_input($module);
        $order = CheckValue::check_input($order);
        $flag = 1;
        if(empty($imageName))
        {
            $image = $oldImage;
        }
        else {

            if ($oldImage != 'default.jpg')
            {
                unlink($imagePath. $oldImage);
            }


            $upload = new uploader;
            $image = $upload -> uploadFile($imagePath, $imageName,$imageTmpName,$imageSize,$size);
            $alert = $upload ->getMessage();
            if($image == false)
            {
                $this -> message = messages::showMessageFailure($alert);
                $flag = 0;
            }
            else
            {
                $this -> message = messages::ShowMessageSuccess($alert);
            }
        }
        if($flag == 1)
        {
            section_cmstype::section_cmstype_UpdateRow($id,$title,$lang,$parent,$image,$date_created,$date_updated,$body,$description,$keywords,$activity,$order,$module);
            $this -> message =  messages::ShowMessageSuccess(MSG_EN_INSERT_SECTION_SUCCESS);
        }

    } 
    
    public function content($id,$title,$parent,$body,$description,$keywords,$activity,$module,$imagePath,$imageName,$imageTmpName,$imageSize,$size,$oldImage,$date)
    {
        $title = CheckValue::check_input($title);
        $parent = CheckValue::check_input($parent);
        $date_created = $date;
        $date_updated = date::nowTime('Asia/Tehran');
        $body = CheckValue::check_input($body);
        $description = CheckValue::check_input($description);
        $keywords = CheckValue::check_input($keywords);
        $activity = CheckValue::check_input($activity);
        $module = CheckValue::check_input($module);
        $flag = 1;
        if(empty($imageName))
        {
            $image = $oldImage;
        }
        else
        {
            $upload = new uploader;
            $image = $upload -> uploadFile($imagePath, $imageName,$imageTmpName,$imageSize,$size);
            $alert = $upload ->getMessage();
            if($image == false)
            {
                $this -> message = messages::showMessageFailure($alert);
                $flag = 0;
            }
            else
            {
                $this -> message = messages::ShowMessageSuccess($alert);
            }
        }
        if($flag == 1)
        {
            content::content_UpdateRow($id,$title,$parent,$image,$date_created,$date_updated,$body,$description,$keywords,$activity,1,2,2);
            $this -> message =  messages::ShowMessageSuccess(MSG_EN_INSERT_SECTION_SUCCESS);
        }

    }
    
    public function getMessage()
    {
        return $this -> message;
    }
}