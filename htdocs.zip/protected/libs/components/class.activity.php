<?php
class activity
{
    public static function change($check,$id,$table)
    {
        if($check != 1 && $check != 0)
        {
           return false;
        }
        else
        {
            if(CheckValue::check_posetive($id)==false)
            {
                return false;
            }
            else
            {
                $query_check = 'UPDATE '.$table.' SET activity=('.$check.') WHERE id='.$_GET['id'].'';
                DatabaseHandler::Execute($query_check);
                return true;
            }
        }
    }
}