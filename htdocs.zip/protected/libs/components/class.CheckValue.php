<?php
  class CheckValue
  {
     public static function check_input($data)
     {
       $data = trim($data);
       $data = stripslashes($data);
       $data = htmlspecialchars($data);
       return $data;
     }
      public static  function  check_int($data)
      {
          if(!filter_var($data, FILTER_VALIDATE_INT))
          {
              return false;
          }
          return true;
      }
     public static function check_email($data)
     {
         if (!preg_match("/([\w\-]+\@[\w\-]+\.[\w\-]+)/",$data))
         {
            return false;
         }
         return true;
     }
      public static function cellPhone($data)
     {
         if (!preg_match("/09(1[0-9]|3[1-9]|2[1-9])-?[0-9]{3}-?[0-9]{4}/",$data))
         {
            return false;
         }
         return true;
     }
     public static function check_name($data)
     {
         if (!preg_match("/^[a-zA-Zاآبپتسجچحخدذرزژسشصضطظعغفقکگلمنوهی ]*$/",$data))
         {
            return false;
         }
         return true;
     }
     public static function check_password($data)
     {
         if (!preg_match("/^[a-zA-Z0-9]*$/",$data))
         {
            return false;
         }
         return true;
     }
     public static function check_exists($data)
     {
         $name = users::users_SelectRow_ByFullname($data);
         if($name)
         {
             return false;
         }
         return true;
     }
      public static function check_posetive($data)
      {
          if(!CheckValue::check_int($data) || $data < 1)
          {
              return false;
          }
          return true;
      }
  }
?>