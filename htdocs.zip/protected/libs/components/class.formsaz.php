<?php
class formsaz
{
    private 
        $resualt
            ;
    public function generate($action,$method,$id,$class,$enctype,$fields)
    {
      
        $form = '<form action="'.$action.'"  method="'.$method.'" class="'.$class.'"  id="'.$id.'" '.$enctype.'></form>';
        $this -> result = ["form"=>$form ,"object"=>$this->object($fields,$id)];
        
    }
    public function object($fields,$form)
    {
$input=[];
foreach($fields as $field)
{
    $checked ='';
    if(isset($field['checked']))
    {
        $checked = 'checked="checked"';
    }
    
    switch ($field['type'])
    {
        case 'select':
            $input[$field['index']]="<select class='$field[class]' id='$field[obj_id]'  name='$field[name]' form='$form' $field[multiple]>";
            foreach ($field['option'] as $option)
            {
                $input[$field['index']].=" <option value='$option[value]' $option[selected]>$option[text]</option>";
            }
            $input[$field['index']].="</select>";
            break;
           
        case 'label' : $input[$field['index']]="<label class='$field[class]' id='$field[obj_id]' for='$field[for]'>$field[name]</label>";
            break;
        case 'radio' : $input[$field['index']]="<input class='$field[class]' value='$field[value]' id='$field[obj_id]' type='$field[type]' name='$field[name]' form='$form'  $checked>";
            break;
        case 'textarea' : $input[$field['index']]="<textarea rows='$field[rows]' cols='$field[cols]' class='$field[class]' id='$field[obj_id]' name='$field[name]' form='$form'>$field[value]</textarea>";
            break;
        default :
            $input[$field['index']]= "<input value='$field[value]' class='$field[class]' id='$field[obj_id]' type='$field[type]' name='$field[name]' form='$form' autocomplete='$field[autocomplete]'  $checked>";
            
    }
    
}
        return $input;

    }


    public function render()
    {
        return $this->result;
    }
}