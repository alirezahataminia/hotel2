<?php
  class RoleProvider
  {
      public static function setUserPermissions($roleID)
      {
          $userPermissions = rolespermissions::selectall_with_roleid($roleID);
          return $userPermissions;
      }
      public static function checkUserPermission($permissionID)
      {     
            $allPermissions = $_SESSION['userInfo']['permissions'];
            $role=  $_SESSION['userInfo']['roles_id'];
            if($role == 1)
            {
                return true;
            }
                
          foreach($allPermissions as $item)
          {   
              if($item['permissions_id'] == $permissionID)
              {
                return true;
              
              }
          }
          return false;
      }
  }

