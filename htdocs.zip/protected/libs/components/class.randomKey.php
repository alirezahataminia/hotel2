<?php
class randomKey
{
    public static function random($counte)
    {
        $char='abcdefghijklmnopqrstuxyvwzABCDEFGHIJKLMNOPQRSTUXYVWZ123456789';
        $charnumber =strlen($char);
        $randomnumber ="";
        for($i=0;$i<$counte;$i++)
        {
            $index = mt_rand(0,$charnumber-1);
            $randomnumber .= $char[$index];

        }
        return $randomnumber;
    }
}