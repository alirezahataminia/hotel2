<?php

require_once('nusoap/nusoap.php');
class PaymentGate
{
    public $Authority = 0;
    

    public static function gotoParsian ($amount, $orderID) 
    {
        // Nusoap library 'nusoap.php' should be available through include_path directive
        // set the URL or path to the WSDL document
//        $wsdl = "https://www.pec24.com/pecpaymentgateway/eshopservice.asmx?wsdl";

        // instantiate the SOAP client object
try{
        $soap = new nusoap_client("https://www.pec24.com/pecpaymentgateway/eshopservice.asmx?wsdl","wsdl");
//        $soap = new soapclient("https://www.pec24.com/pecpaymentgateway/eshopservice.asmx?wsdl",true);
}
catch(Exception $e){
        echo $e;}
        // get the SOAP proxy object, which allows you to call the methods directly
        $proxy = $soap->getProxy();


        $parameters = array('pin'=>'Sy4Eeu76Ba0w2u6X4eLk','amount'=>$amount,'orderId'=>$orderID,'callbackUrl'=>"http://keramatifar.ir/paymentreturn.php?orderID=$orderID" ,'authority'=>0,'status'=>0);

        $result = $proxy->PinPaymentRequest($parameters);
        return $result;

    }

//  this function is to Validate Payment
    public static function check_Payment_Parsian ($auth) 
    {

       //   include("nusoap/nusoap.php");

           // set the URL or path to the WSDL document
            $wsdl = "https://www.pec24.com/pecpaymentgateway/eshopservice.asmx?wsdl";

            // instantiate the SOAP client object
            $soap = new nusoap_client($wsdl,true);

            // get the SOAP proxy object, which allows you to call the methods directly
            $proxy = $soap->getProxy();

            // set parameter parameters (PinPaymentEnquiry^)
            $parameters = array('pin'=>'Sy4Eeu76Ba0w2u6X4eLk','authority'=>$auth,'status'=>0);

            // get the result, a native PHP type, such as an array or string
            $result = $proxy->PinPaymentEnquiry($parameters);
             return $result;

    }
    
    public static function GetPaymentUniqID($registerID)
    {
        $sql = 'CALL payment_uniq_GetUniqID(:registerID)';
        $params = array (':registerID' => $registerID);
        return DatabaseHandler::GetOne($sql, $params);
    }

}
?>