<?php
class date
{
    public static function nowTime($timeZone)
    {
        date_default_timezone_set($timeZone);
        return date('Y-m-d h:i:s');
    }
}