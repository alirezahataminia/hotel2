<?php
class getMail
{
    public static function newsRegister($email,$fullname)
    {
        if(CheckValue::check_email($email) && CheckValue::check_name($fullname))
        {
            $check = DatabaseHandler::GetRow("SELECT * FROM users WHERE email='$email'");
            if($check['email'])
            {
                return 0;
            }
              else
              {
                  $char='abcdefghijklmnopqrstuxyvwzABCDEFGHIJKLMNOPQRSTUXYVWZ123456789';
                  $charnumber =strlen($char);
                  $randomnumber ="";
                  for($i=0;$i<70;$i++)
                  {
                      $index = mt_rand(0,$charnumber-1);
                      $randomnumber .= $char[$index];

                  }
                  $txtDate =  date::nowTime('Asia/Tehran');
                  users::users_Insert($email,md5('sd1234%!a'),0,$txtDate,4,'no','no','no',md5($randomnumber),0);
                  return 1;
              }

        }
    }
}