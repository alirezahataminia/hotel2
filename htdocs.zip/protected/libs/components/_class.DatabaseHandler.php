<?php
  class DatabaseHandler
  {
      public static function connectToDb()
      {
          mysql_connect('localhost', 'root', '');
          mysql_select_db('eshop');
          mysql_query("SET NAMES UTF8");
      }
      public static function getAllRecords($table)
      {
          self::connectToDb();
          return mysql_query("SELECT * FROM $table");
      }
      public static function getRecordByID($table, $id)
      {
          self::connectToDb();
          return mysql_query("SELECT * FROM $table WHERE ID = $id");
      }
      public static function getFieldByID($table, $id, $field)
      {
          self::connectToDb();
          return mysql_query("SELECT $field FROM $table WHERE ID = $id");
      }
  }
?>
