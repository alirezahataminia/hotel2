<?php
class uploader
{
    private
    $message = ''
    ;


    public function uploadFile($target_dir,$file_name,$file_type,$file_size,$size)
    {
        $target_file = $target_dir . basename($file_name);
        $target_tumbFileName = $target_dir . 'thumb/' . basename($file_name);
        $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
            $check = getimagesize($file_type);
            if($check == false)
            {
                $this -> message = 'Error in type of file';
                return false;
            }

            elseif ($file_size > $size)
            {
                $this -> message = MSG_EN_IMAGE_SIZE_FAILURE;
                return false;
            }
            elseif($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif")
            {
                $this -> message = MSG_EN_IMAGE_TYPE_FAILURE;
                return false;
            }
            else
            {
                    if (file_exists($target_file))
                    {
                        $additional = 1 ;
                        while (file_exists($target_file)) {
                            $info = pathinfo($target_file);
                            $target_file = $info['dirname'] . '/'
                                . $info['filename'] . '(' .$additional . ')'
                                . '.' . $info['extension'];


                            $target_tumbFileName = $info['dirname'] . '/thumb/'
                                . $info['filename'] . '(' .$additional . ')'
                                . '.' . $info['extension'];


                            $additional++;
                        }
                    }
                if (move_uploaded_file($file_type, $target_file))
                {
                    thumbnail::thumb($target_file,100,$target_tumbFileName);
                    $info = pathinfo($target_file);
                    $name = $info['filename']. '.' . $info['extension'];
                    $this -> message = MSG_EN_INSERT_SECTION_SUCCESS;
                    return $name;
                }
                else
                {
                    $this -> message = MSG_EN_FATAL_FAILURE;
                    return false;
                }
            }
    }
    public function getMessage()
    {
        return $this->message;
    }
}