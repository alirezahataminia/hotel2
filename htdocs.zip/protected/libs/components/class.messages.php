<?php
  class messages
  {
      public static function showMessageInfo($text)
      {
          return
              '
          <div class="row">
            <div class="container">
                <div class="col-lg-12">

                </div>
            </div>
          </div>
          ';
      }
      public static function showMessageFailure($text)
      {
          return
              '

                      <div role="alert" class="alert alert-danger alert-dismissible">
                      <span class="glyphicon glyphicon-remove"></span>
                      <button aria-label="Close" data-dismiss="alert" class="puul-left close" type="button"><span aria-hidden="true">×</span></button>
                      '.
                            $text
                        .'
                  </div>
          ';
                
      }
      public static function ShowMessageSuccess($text)
      {
          return
          '
          <div class="alert alert-success">
                      <span class="glyphicon glyphicon-ok"></span>
                      <button aria-label="Close" data-dismiss="alert" class="puul-left close" type="button"><span aria-hidden="true">×</span></button>
                            '.
                                $text
                            .'
                  </div>

          ';
      }
      public static function commentShowMessageFailure($text)
      {
          return
              '
          <div class="row">
            <div class="container">
                <div class="col-lg-12">

                </div>
            </div>
          </div>
          ';
      }
      public static function commentShowMessageInfo($text)
      {
          return
              '
          <div class="row">
            <div class="container">
                <div class="col-lg-12">

                </div>
            </div>
          </div>
          ';
      }
  }
?>
