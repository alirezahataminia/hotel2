<?php
class urlManage
{
    static function getURL($url)
    {
        $url = explode('/',preg_replace('/^(\/)/','',$url));
        return $url;
    }
}