<?php
class sendMail
{
    public static function validate($to,$message,$from,$site)
    {
        $subject = $from;
        $message2  = "<a href=" . $site ."?" . $message . "> برای ثبت ایمیل در سایت اینجا راکلیک کنید </a>";
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= 'From:'.$from.' ' . "\r\n";

        mail($to,$subject,$message2,$headers);
    }
}