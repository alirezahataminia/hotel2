<?php
class filter
{
    public static function filterWord($data)
    {
        return substr("$data", 0, 25);
    }
}