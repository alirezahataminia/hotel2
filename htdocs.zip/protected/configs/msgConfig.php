<?php
define('MSG_INSERT_SECTION_SUCCESS', '<strong> عملیات موفق بود! </strong> عملیات درج بخش با موفقیت انجام شد');
define('MSG_UPDATE_SECTION_SUCCESS', '<strong> عملیات موفق بود! </strong> عملیات به روز رسانی با موفیقت انجام شد');
define('MSG_DELETE_SECTION_SUCCESS', '<strong> عملیات حذف موفق بود! </strong> بخش با موفقیت حذف شد');
define('MSG_DELETE_OPTION_SUCCESS', '<strong> عملیات حذف موفق بود! </strong> گزینه مورد نظر با موفقیت حذف شد!');
define('MSG_INSERT_GROUP_SUCCESS', '<strong> عملیات درج موفق بود! </strong> عملیات درج گروه با موفقیت انجام شد');
define('MSG_INSERT_ARTICLE_SUCCESS', '<strong> عملیات درج موفق بود! </strong> عملیات درج مطلب با موفقیت انجام شد');
define('MSG_SWAP_DOWN_SECTION_SUCCESS', '<strong> عملیات جابه جایی موفق بود! </strong> بخش مورد نظر با موفقیت جا به جا شد');
define('MSG_CONTACT_SUCCESS', '<strong> عملیات ارسال موفق بود! </strong> پیام شما با موفقیت ارسال شد');
define('MSG_INSERT_SECTION_EXISTS_FAILURE', '<strong>عملیات درج بخش ناموفق بود</strong> نام بخش وارد شده تکراری است');
define('MSG_INSERT_CMSTYPE_EXISTS_FAILURE', '<strong>عملیات درج گروه ناموفق بود</strong> نام گروه وارد شده تکراری است');
define('MSG_UPDATE_SECTION_EXISTS_FAILURE', '<strong>عملیات به روزرسانی بخش ناموفق بود!</strong> نام بخش وارد شده تکراری است');
define('MSG_CELLPHONE_FAILURE', '<strong> عملیات ارسال ناموفق بود! </strong> شماره تلفن همراه وارد شده اشتباه است');
define('MSG_SECTION_DELETE_NOTEXIST_FAILURE', '<strong>عملیات حذف بخش ناموفق بود</strong> بخش جهت حذف یافت نشد');
define('MSG_CMSTYPE_EXIST_FAILURE', '<strong>عملیات حذف بخش ناموفق بود</strong> این بخش شامل گروه می باشد');
define('MSG_IMAGE_TYPE_FAILURE', '<strong>عملیات آپلود تصویر ناموفق بود</strong> تصویر ارسال شده نامعتبر است');
define('MSG_LOGIN_FAILURE', 'نام کاربری یا کلمه عبور اشتباه است');
define('MSG_FIELD_EMPTY_FAILURE', '<strong>عملیات ارسال انجام نشد! </strong> هیچ فیلدی نباید خالی باشد');
define('MSG_EMAIL_FAILURE', '<strong>عملیات ارسال انجام نشد! </strong> ایمیل وارد شده معتبر نیست');
define('MSG_FULLNAME_FAILUREMSG_FULLNAME_FAILURE', '<strong>عملیات ارسال انجام نشد! </strong> از کاراکترهای مجاز برای فیلد ناماستفاده کنید');
define('MSG_CAPTCHA_FAILURE', '<strong>عملیات ارسال انجام نشد! </strong> تصویر امنتیتی صحیح نیست');
define('MSG_EN_IMAGE_TYPE_FAILURE', '<strong>Oops error </strong> only JPG, JPEG, PNG & GIF files are allowed.');
define('MSG_EN_IMAGE_SIZE_FAILURE', '<strong>Oops, error </strong> Your image is too large!');
define('MSG_EN_FATAL_FAILURE', '<strong>fatal error </strong>');
define('MSG_EN_TITLE_EMPTY_FAILURE', '<strong> Title is required </strong>');
define('MSG_EN_INSERT_SECTION_SUCCESS', '<strong> Good Job! </strong> section is created successfully');

