<?php

// define('SITE_ROOT', dirname(dirname(dirname(__FILE__))).'/');
 define('SITE_ROOT', '' );

//ROOT DIRECTORIS
define('ASSETS_DIR',SITE_ROOT. 'assets/');
//echo ASSETS_DIR;
// print_r($_SERVER);
define('COMPILE_DIR',SITE_ROOT. 'casch/');
define('ERRORS_LOG_DIR',SITE_ROOT.'errors_log/');
define('PROTECTED_DIR', SITE_ROOT. 'protected/');
define('VIEW_DIR',SITE_ROOT.'view/');
define('UPLOADS_DIR',SITE_ROOT. 'uploads/');

//ASSETS  DIRECTOIS
define('ASSETS_ADMIN_DIR', ASSETS_DIR . 'admin');
define('ASSETS_FRONT_DIR', ASSETS_DIR . 'front');
define('ASSETS_PUBLIC_DIR', ASSETS_DIR . 'public');


//ASSETS PUBLIC DIRECTOIS
define('PUBLIC_CSS_DIR', ASSETS_PUBLIC_DIR . '/css');
define('PUBLIC_FILES_DIR', ASSETS_PUBLIC_DIR . '/files');
define('PUBLIC_FONTS_DIR', ASSETS_PUBLIC_DIR . '/fonts');
define('PUBLIC_IMG_DIR', ASSETS_PUBLIC_DIR . '/images');
define('PUBLIC_JS_DIR', ASSETS_PUBLIC_DIR . '/js');
define('PUBLIC_LANG_DIR', ASSETS_PUBLIC_DIR . '/lang');

//PROTECTED DIRECTORIS
define('CONFIGS_DIR', PROTECTED_DIR . 'configs/');
define('LIBS_DIR', PROTECTED_DIR . 'libs/');
define('CONTROLLERS_DIR', PROTECTED_DIR . 'controllers/');
define('MODELS_DIR', PROTECTED_DIR . 'models/');

//VIEW DIRECTORIS
define('ADMIN_TEMPLATE_DIR', VIEW_DIR . 'admin/');
define('FRONT_TEMPLATE_DIR', VIEW_DIR . 'front/');

//CONTROLLER DIRECTORIS
define('ADMIN_CONTROLLERS_DIR', CONTROLLERS_DIR . 'admin/');
define('FRONT_CONTROLLERS_DIR', CONTROLLERS_DIR . 'front/');

//LIBS DIRECTORYS
define('COMPONENTS_DIR', LIBS_DIR . 'components/');
define('SMARTY_PLUGINS_DIR', LIBS_DIR . 'smarty_plugins');
define('SMARTY_DIR', LIBS_DIR . 'smarty/');

//XCRUD CONFIG
define('XCRUD_DIR', LIBS_DIR . 'xcrud/');
define('XCRUD_FILE', XCRUD_DIR . 'xcrud.php');
define('XCRUD_LANG', 'en');


//Error Handler Configs
define('IS_WARNING_FATAL', true);
define('DEBUGGING', true);
// The error types to be reported
define('ERROR_TYPES', E_ALL);
// Settings about mailing the error messages to admin
define('SEND_ERROR_MAIL', true);
define('ADMIN_ERROR_MAIL', 'nemat.mashkani@gmail.com');
define('SENDMAIL_FROM', 'email site');
ini_set('sendmail_from', SENDMAIL_FROM);

// By default we don't log errors to a file
define('LOG_ERRORS', true);
define('LOG_ERRORS_FILE', ERRORS_LOG_DIR.'errorsLog.txt'); // Windows
//define('LOG_ERRORS_FILE', '/home/username/tshirtshop/errors.log'); // Linux
define('SITE_GENERIC_ERROR_MESSAGE', '<h1>کاربر گرامی فعلا سایت مشغول است بعداا تماس بگیرید</h1>');
define('SECURITY_KEY', ';klAsj@k;dfjsdfndmvbiu%$_+1%');

//set time zone
define('TIMEZONE', 'Asia/Tehran');
date_default_timezone_set(TIMEZONE);

//CONFIG AND SET TEMPLATE 
define('ALLOW_CHANGE_THEME', true);

$front_theme = 'tmp_hotel';
if(isset($_COOKIE['front_theme']))
    $front_theme = $_COOKIE['front_theme'];  
define('FRONT_CURRENT_THEME', FRONT_TEMPLATE_DIR . $front_theme);
define('FRONT_CURRENT_ASSETS', ASSETS_FRONT_DIR.'/' . $front_theme);

$admin_theme = 'admin';
if(isset($_COOKIE['admin_theme']))
    $admin_theme = $_COOKIE['admin_theme'];
define('ADMIN_CURRENT_THEME', ADMIN_TEMPLATE_DIR . $admin_theme);
define('ADMIN_CURRENT_ASSETS', ASSETS_ADMIN_DIR.'/' . $admin_theme);
define('SITE_LANG', 'fa');


//DATABASE SETTING
define('DB_PERSISTENCY', 'true');
define('DB_SERVER', '127.0.0.1');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_DATABASE', 'halal2');
define('PDO_DSN', 'mysql:host=' . DB_SERVER . ';dbname=' . DB_DATABASE);
define('THUMB_WIDTH',300);
define('THUMB_HEIGHT',300);
//Google Analytic SETTING
define('GOOGLE_ANLYTIC_ACTIVE', false);
define('GOOGLE_ANLYTIC_CODE', '');
//Site info
define('SITE_EMAIL', 'info@articodes.ir');
function autoload($class) 
{
    
    if($class == 'Application')
    {
        if(file_exists(LIBS_DIR. $class . '.php')) 
        {

            require LIBS_DIR. $class . '.php';
        }

    }
    else if(file_exists(COMPONENTS_DIR . 'class.' . $class . '.php'))
    {
        require COMPONENTS_DIR .'class.' . $class . '.php' ; 

    }
    else if(file_exists(XCRUD_DIR . $class . '.php'))
    {
        include_once XCRUD_FILE ;

    }

    else if(file_exists(SMARTY_PLUGINS_DIR. $class . '.php'))
    {
        include SMARTY_PLUGINS_DIR . $class . '.php';
    }

    else if(file_exists(MODELS_DIR .'model.'. $class . '.php'))
    {
        include MODELS_DIR .'model.'. $class . '.php';

    }

}
spl_autoload_register('autoload');

ErrorHandler::SetHandler(ERROR_TYPES);

